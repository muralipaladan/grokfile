//#region node_modules/.nitro/vite/services/ssr/assets/questions-C2LG63w4.js
var chapters = [
	{
		id: "ch1",
		roman: "I",
		titleEn: "Introductory",
		titleMl: "ആമുഖം",
		paras: "1–10",
		blurbMl: "ബജറ്റ് എന്താണ്, നാല് ഘട്ടങ്ങൾ, അക്കൗണ്ടുകളുടെ മൂന്ന് ഭാഗങ്ങൾ, അഞ്ച് തട്ട് വർഗീകരണം, ചാർജ്ഡ്/വോട്ടഡ്."
	},
	{
		id: "ch2",
		roman: "II",
		titleEn: "Definitions",
		titleMl: "നിർവചനങ്ങൾ",
		paras: "11",
		blurbMl: "ഗ്രാന്റ്, അപ്രോപ്രിയേഷൻ, റിയാപ്രോപ്രിയേഷൻ, സറണ്ടർ, റിസംപ്ഷൻ, ന്യൂ സർവീസ്, യൂണിറ്റ് ഓഫ് അപ്രോപ്രിയേഷൻ."
	},
	{
		id: "ch3",
		roman: "III",
		titleEn: "Preparation of the budget — I",
		titleMl: "ബജറ്റ് തയ്യാറാക്കൽ — I",
		paras: "12–31",
		blurbMl: "കാഷ് ബേസിസ്, Part I / Part II, റിവൈസ്ഡ് എസ്റ്റിമേറ്റ്, തീയതികൾ, മാർച്ച് ശമ്പളം, ലമ്പ് സം."
	},
	{
		id: "ch4",
		roman: "IV",
		titleEn: "Preparation of the budget — II",
		titleMl: "ബജറ്റ് തയ്യാറാക്കൽ — II",
		paras: "32–46",
		blurbMl: "എസ്റ്റിമേറ്റിങ് ഓഫീസർമാർ, നമ്പർ സ്റ്റേറ്റ്‌മെന്റുകൾ, സ്റ്റാഫ്, വർക്ക്‌സ് അനുബന്ധം."
	},
	{
		id: "ch5",
		roman: "V",
		titleEn: "Preparation of the budget — III",
		titleMl: "ബജറ്റ് തയ്യാറാക്കൽ — III",
		paras: "47–53",
		blurbMl: "ബജറ്റ് രേഖകൾ, ഏജൻസി സബ്ജക്റ്റ്, പെർഫോമൻസ് ബജറ്റ്, ആസ്തി-ബാധ്യത."
	},
	{
		id: "ch6",
		roman: "VI",
		titleEn: "Passing of the budget",
		titleMl: "ബജറ്റ് പാസാക്കൽ",
		paras: "54–60",
		blurbMl: "അവതരണം, ജനറൽ ഡിസ്കഷൻ, ഡിമാൻഡ് വോട്ട്, അപ്രോപ്രിയേഷൻ ബിൽ, Vote on Account, ടോക്കൺ ഗ്രാന്റ്."
	},
	{
		id: "ch7",
		roman: "VII",
		titleEn: "Execution of the budget — I",
		titleMl: "ബജറ്റ് നിർവഹണം — I",
		paras: "61–80",
		blurbMl: "ചെലവ് നിയന്ത്രണം, Warning Slip, Appropriation Control, Letter of Credit, KBM 12–21, റിക്കൺസിലിയേഷൻ."
	},
	{
		id: "ch8",
		roman: "VIII",
		titleEn: "Execution of the budget — II",
		titleMl: "ബജറ്റ് നിർവഹണം — II",
		paras: "81–97",
		blurbMl: "റിയാപ്രോപ്രിയേഷൻ, സപ്ലിമെന്ററി, സറണ്ടർ, റിസംപ്ഷൻ, ന്യൂ സർവീസ്, കണ്ടിജൻസി ഫണ്ട്, എക്സസ് ഗ്രാന്റ്."
	},
	{
		id: "ch9",
		roman: "IX",
		titleEn: "Review of the budget — I (Audit Report)",
		titleMl: "ബജറ്റ് അവലോകനം — I",
		paras: "98–107",
		blurbMl: "CAG ഓഡിറ്റ്, Draft Paragraph, 6 ആഴ്ച / 3 മാസം, അക്കൗണ്ടബിലിറ്റി."
	},
	{
		id: "ch10",
		roman: "X",
		titleEn: "Public Accounts Committee",
		titleMl: "പബ്ലിക് അക്കൗണ്ട്സ് കമ്മിറ്റി",
		paras: "108",
		blurbMl: "11 അംഗങ്ങൾ, 2 വർഷം, മന്ത്രി അല്ല, Appropriation Accounts, Rules 231–232."
	},
	{
		id: "ch11",
		roman: "XI",
		titleEn: "Estimates Committee",
		titleMl: "എസ്റ്റിമേറ്റ്സ് കമ്മിറ്റി",
		paras: "109",
		blurbMl: "സമ്പദ്‌വ്യവസ്ഥ, ബദൽ നയം, ഫോം ഓഫ് എസ്റ്റിമേറ്റ്. Rules 233–235."
	},
	{
		id: "ch12",
		roman: "XII",
		titleEn: "Committee on Public Undertakings",
		titleMl: "പബ്ലിക് അണ്ടർടേക്കിങ്‌സ് കമ്മിറ്റി",
		paras: "110",
		blurbMl: "1968 നവംബർ, 51% മുതൽമുടക്ക്, Fourth Schedule, Rules 236–237."
	},
	{
		id: "app",
		roman: "App",
		titleEn: "Appendices & Forms",
		titleMl: "അനുബന്ധങ്ങളും ഫോമുകളും",
		paras: "App 1–17 · KBM 1–22",
		blurbMl: "സ്റ്റാൻഡേർഡ് ഒബ്ജക്റ്റ് ഹെഡുകൾ, ചാർജ്ഡ് ലിസ്റ്റ്, ന്യൂ സർവീസ് പരിധി, KCF Act, KBM ഫോമുകൾ."
	}
];
function chapterById(id) {
	return chapters.find((c) => c.id === id);
}
function Q(id, chapterId, para, difficulty, question, options, answer, explanationMl, explanationEn, tags = []) {
	return {
		id,
		chapterId,
		para,
		difficulty,
		question,
		options,
		answer,
		explanationMl,
		explanationEn,
		tags
	};
}
var app = [
	Q("a-01", "app", "App 1", "easy", "How many standard objects of expenditure (standard detailed heads) are listed in Appendix 3?", [
		"12",
		"20",
		"26",
		"32"
	], 2, "App 3-ൽ 26 standard objects — Salaries മുതൽ Other Charges വരെ.", "26 standard detailed heads in Appendix 3.", ["objects"]),
	Q("a-02", "app", "App 3", "easy", "The first standard object of expenditure is —", [
		"Wages",
		"Salaries",
		"Office Expenses",
		"Other Charges"
	], 1, "1. Salaries 2. Wages 3. Travel Expenses 4. Office Expenses… 26. Other Charges.", "Salaries is object 1.", ["objects"]),
	Q("a-03", "app", "App 3", "easy", "'Other Charges' is described as —", [
		"the first object head",
		"a residuary head, also including rewards and prizes",
		"synonymous with Office Expenses",
		"charged expenditure only"
	], 1, "Other Charges = ബാക്കിയുള്ളവ. Rewards, prizes ഇവിടെ.", "Residuary head; includes rewards and prizes.", ["objects"]),
	Q("a-04", "app", "App 3", "medium", "Leave Travel Concession is classified under —", [
		"Travel Expenses",
		"Salaries",
		"Office Expenses",
		"Hospitality Expenses"
	], 1, "Travel Expenses: യാത്രാ ചെലവ്, conveyance, fixed TA; LTC ഒഴിവ്. LTC Salaries-ൽ (pay & allowances except travel other than LTC).", "LTC is under Salaries, not Travel Expenses.", ["objects"]),
	Q("a-05", "app", "App 3", "medium", "Wages of staff paid out of contingencies are classified under —", [
		"Salaries",
		"Wages",
		"Office Expenses",
		"Other Charges"
	], 1, "Wages: labourers + contingency staff (KFC Vol I Ch V). Office Expenses-ൽ അവരുടെ വേതനം ഇടരുത്.", "Wages — including contingency-paid staff.", ["objects"]),
	Q("a-06", "app", "App 3", "medium", "Refreshments at inter-departmental meetings are booked under —", [
		"Hospitality Expenses",
		"Office Expenses",
		"Secret Service",
		"Publications"
	], 1, "യോഗങ്ങളിലെ റിഫ്രഷ്‌മെന്റ് = Office Expenses. Hospitality = ഉന്നതർക്കുള്ള entertainment allowances.", "Meeting refreshments: Office Expenses, not Hospitality.", ["objects"]),
	Q("a-07", "app", "App 3", "medium", "Purchase and maintenance of an ambulance van is classified under —", [
		"Office Expenses",
		"Motor Vehicles",
		"Machinery and Equipment",
		"Travel Expenses"
	], 1, "ഓഫീസ് ഉപയോഗത്തിനുള്ള സ്റ്റാഫ് കാർ = Office Expenses. Functional vehicle (ambulance) = Motor Vehicles (object 16).", "Functional vehicles (e.g. ambulance) = Motor Vehicles.", ["objects"]),
	Q("a-08", "app", "App 3", "medium", "Printing of office codes and manuals is classified under —", [
		"Office Expenses",
		"Publications",
		"Advertising, Sales and Publicity Expenses",
		"Other Charges"
	], 1, "Codes/Manuals = Publications. Publicity printing = Advertising, Sales and Publicity.", "Office codes/manuals: Publications. Publicity material: Advertising.", ["objects"]),
	Q("a-09", "app", "App 3", "medium", "Rent of hired buildings and municipal taxes fall under —", [
		"Office Expenses",
		"Rents, Rates and Taxes/Royalty",
		"Other Charges",
		"Minor Works"
	], 1, "Object 6: rent, municipal rates/taxes, land lease. Office running contingencies അല്ല.", "Object 6: Rents, Rates and Taxes/Royalty.", ["objects"]),
	Q("a-10", "app", "App 3", "hard", "Legal fees and consultancy charges are classified under —", [
		"Salaries",
		"Office Expenses",
		"Payment for professional and special services",
		"Secret Service Expenditure"
	], 2, "Object 5: legal, consultancy, examiners/invigilators, professional services. ഓഫീസ് ഓടിക്കാനുള്ള മറ്റ് വകുപ്പ് സേവനം = Office Expenses.", "Professional and special services (object 5).", ["objects"]),
	Q("a-11", "app", "App 4", "easy", "Emoluments and allowances of the Governor are —", [
		"voted",
		"charged on the Consolidated Fund (Art. 202(3)(a))",
		"met from Public Account",
		"paid from Contingency Fund as a rule"
	], 1, "App 4 / Art. 202(3)(a): ഗവർണറുടെ emoluments charged.", "Charged — Article 202(3)(a).", ["charged"]),
	Q("a-12", "app", "App 4", "easy", "Salaries of the Speaker and Deputy Speaker are —", [
		"voted",
		"charged (Art. 202(3)(b))",
		"paid by the Secretariat from Office Expenses",
		"agency expenditure"
	], 1, "Speaker, Deputy Speaker: charged. Art. 202(3)(b).", "Charged — Article 202(3)(b).", ["charged"]),
	Q("a-13", "app", "App 4", "easy", "Debt charges for which the State is liable are —", [
		"voted annually in full detail as a Demand",
		"charged (Art. 202(3)(c))",
		"ignored in the AFS",
		"Part II schemes"
	], 1, "പലിശ, sinking fund, redemption — charged. Art. 202(3)(c).", "Charged — Article 202(3)(c).", ["charged"]),
	Q("a-14", "app", "App 4", "easy", "Salaries and allowances of High Court Judges are —", [
		"voted",
		"charged (Art. 202(3)(d))",
		"met from the Contingency Fund only",
		"Public Account"
	], 1, "ഹൈക്കോടതി ജഡ്ജിമാർ: charged. Art. 202(3)(d).", "Charged — Article 202(3)(d).", ["charged"]),
	Q("a-15", "app", "App 4", "easy", "Sums required to satisfy a court decree or arbitral award are —", [
		"always voted as a New Service",
		"charged (Art. 202(3)(e)) — decretal claims",
		"office expenses",
		"wages"
	], 1, "Decretal/arbitral amounts charged. Art. 202(3)(e).", "Charged — Article 202(3)(e).", ["charged", "decretal"]),
	Q("a-16", "app", "App 4", "medium", "Administrative expenses of the High Court, including salaries of officers and servants of the Court, are charged under —", [
		"Article 202(3)(a)",
		"Article 229(3)",
		"Article 322",
		"Article 290A"
	], 1, "Art. 229(3): ഹൈക്കോടതി ഭരണച്ചെലവ് charged. ജഡ്ജിമാർ 202(3)(d); സ്റ്റാഫ്/admin 229(3).", "Article 229(3).", ["charged"]),
	Q("a-17", "app", "App 4", "medium", "Payment to the Travancore Devaswom Fund is charged under —", [
		"Article 202(3)(b)",
		"Article 266",
		"Article 290A",
		"Article 322"
	], 2, "Art. 290A: Travancore Devaswom Fund — charged.", "Article 290A.", ["charged"]),
	Q("a-18", "app", "App 4", "medium", "Expenses of the State Public Service Commission are charged under —", [
		"Article 202(3)(a)",
		"Article 229(3)",
		"Article 322",
		"Article 151"
	], 2, "KPSC: Art. 322 — അംഗങ്ങളും സ്റ്റാഫും, പെൻഷൻ ഉൾപ്പെടെ charged.", "Article 322.", ["charged"]),
	Q("a-19", "app", "App 13", "hard", "As per G.O.(P) 1803/99/Fin (revised Appendix 13), additional staff arising from a new policy is a New Service when cost exceeds —", [
		"Rs 1 lakh recurring",
		"Rs 5 lakh per annum recurring or Rs 10 lakh non-recurring, taking the scheme as a whole",
		"Rs 25 lakh always",
		"Rs 2,500"
	], 1, "1999 C.S. No. 1/99: സ്റ്റാഫ്/ന്യൂ പോളിസി — Rs 5 lakh recurring അല്ലെങ്കിൽ Rs 10 lakh non-recurring (സ്കീം മൊത്തം).", "Rs 5 lakh recurring or Rs 10 lakh non-recurring (scheme as a whole).", ["new-service"]),
	Q("a-20", "app", "App 13", "hard", "A new work is a New Service (revised App 13) when cost exceeds —", [
		"Rs 10,000",
		"Rs 1 lakh",
		"Rs 20 lakh (and irrespective of amount if it involves a new policy)",
		"Rs 2,500"
	], 2, "പുതിയ വർക്ക് > Rs 20 lakh. പുതിയ നയം/വലിയ നയമാറ്റം ഉണ്ടെങ്കിൽ തുക നോക്കേണ്ട.", "Rs 20 lakh; new policy → New Service irrespective of amount.", ["new-service"]),
	Q("a-21", "app", "App 13", "hard", "Revision of scales of pay is a New Service when extra cost exceeds —", [
		"Rs 2 lakh",
		"Rs 5 lakh",
		"Rs 25 lakh per annum (revision includes pension; periodical DA is not New Service)",
		"Rs 1 crore"
	], 2, "Pay/pension revision > Rs 25 lakh a year = New Service. Periodical DA അല്ല.", "Over Rs 25 lakh p.a.; DA revision is not New Service.", ["new-service"]),
	Q("a-22", "app", "App 13", "hard", "Ways and Means Advances (other than those treated as loans to boards/companies) —", [
		"are always New Service",
		"need not be treated as New Service, but must be brought to the notice of the Legislature in the next session",
		"are charged under Art. 322",
		"lapse automatically"
	], 1, "W&M advances New Service അല്ല; അടുത്ത സെഷനിൽ Supplementary-യുടെ Annexure-ൽ അറിയിക്കണം. ബോർഡുകൾക്കുള്ള W&M = loan പരിധി.", "Not New Service; inform Legislature next session.", ["new-service"]),
	Q("a-23", "app", "App 13", "hard", "Loans and investments in private sector / joint sector companies —", [
		"follow the Rs 5 lakh staff limit",
		"constitute New Service whatever the magnitude",
		"are never voted",
		"are Public Account only"
	], 1, "സ്വകാര്യ/ജോയിന്റ് സെക്ടർ ലോൺ/നിക്ഷേപം — തുക എത്രയായാലും New Service. Joint sector = private.", "New Service irrespective of amount. Joint sector treated as private.", ["new-service"]),
	Q("a-24", "app", "App 13", "medium", "All loans given for the first time —", [
		"need not be voted",
		"constitute New Service",
		"are charged",
		"go to Contingency Fund as token"
	], 1, "ആദ്യ ലോൺ = New Service. ആദ്യ നിക്ഷേപവും അങ്ങനെ.", "First-time loans are New Service.", ["new-service"]),
	Q("a-25", "app", "App 13", "medium", "Amounts paid to cover losses or a concessional gap of an undertaking are termed —", [
		"Grant-in-aid",
		"Contribution",
		"Subsidy",
		"Other Charges only"
	], 2, "Subsidy: നഷ്ടം/ഇളവ് വിടവ് നികത്താൻ. GIA: utilisation ഓഡിറ്റ്. Contribution: utilisation നിബന്ധനയില്ല.", "Subsidy as defined in the 1999 amendment.", ["definitions"]),
	Q("a-26", "app", "App 13", "medium", "Amounts paid to an institution to cover costs, subject to scrutiny/audit of utilisation, are —", [
		"Subsidy",
		"Grant-in-aid",
		"Contribution",
		"Ways and Means"
	], 1, "GIA = utilisation audit ഉണ്ട്. Contribution = നിബന്ധനയില്ല.", "Grant-in-aid.", ["definitions"]),
	Q("a-27", "app", "App 1", "medium", "The Public Account includes which sector among the following?", [
		"A. Tax Revenue",
		"E. Public Debt",
		"I. Small Savings, Provident Funds, etc.",
		"H. Transfer to Contingency Fund"
	], 2, "Public Account sectors I–N: Small Savings/PF, Reserve Funds, Deposits and Advances, Suspense, Remittances, Cash Balance. E–H Consolidated Fund-ലെ debt/loans/CF transfer.", "I. Small Savings, Provident Funds, etc. is in the Public Account.", ["public-account"]),
	Q("a-28", "app", "App 1", "medium", "Transfer to Contingency Fund is sector —", [
		"D",
		"H",
		"N",
		"C"
	], 1, "H. Transfer to Contingency Fund — CF-ലെ Public Debt/Loans വിഭാഗം.", "Sector H.", ["sectors"]),
	Q("a-29", "app", "App 1", "easy", "Appendix 2 of the Manual (List of Major and Minor Heads) is —", [
		"printed inside Chapter I",
		"published separately",
		"the same as Appendix 17",
		"only in Malayalam"
	], 1, "Major/Minor heads പ്രത്യേക വാല്യം (പഴയ Appendix A recast).", "Published separately.", ["appendix-2"]),
	Q("a-30", "app", "App 17", "easy", "Constitutional provisions on budget, finance and accounts are extracted in —", [
		"Appendix 7",
		"Appendix 13",
		"Appendix 15",
		"Appendix 17"
	], 3, "App 17: Arts 202–207, 266, 267, 151 തുടങ്ങിയവ ഒരിടത്ത്.", "Appendix 17.", ["constitution"]),
	Q("a-31", "app", "App 14", "easy", "The Kerala Contingency Fund Act and Rules are reproduced in —", [
		"Appendix 11",
		"Appendix 12",
		"Appendix 14",
		"Appendix 16"
	], 2, "App 14 = KCF Act 1957 + Rules.", "Appendix 14.", ["contingency-fund"]),
	Q("a-32", "app", "App 5", "medium", "The system of Gross Vote on stores/suspense is explained in —", [
		"Appendix 3",
		"Appendix 5 (Circular 72/76/Fin dated 27 July 1976)",
		"Appendix 8",
		"Appendix 16"
	], 1, "App 5: Gross vote — stores suspense. Circular 72/76/Fin 27 Jul 1976.", "Appendix 5, Circular 72/76/Fin.", ["gross-vote"]),
	Q("a-33", "app", "KBM 22", "easy", "Separate KBM 22 forms should be used for —", [
		"each month of LTC",
		"charged and voted, and for revenue and capital",
		"PAC and COPU",
		"Plan and Performance Budget only"
	], 1, "Charged/voted വേറെ; revenue/capital വേറെ — KBM 22.", "Separate forms for charged/voted and revenue/capital.", ["forms"]),
	Q("a-34", "app", "App 10", "medium", "Appendix 10 lists officers who must —", [
		"vote the Appropriation Bill",
		"reconcile their expenditure figures with treasury figures before sending them to the superior controlling authority",
		"issue Warning Slips",
		"sit on PAC"
	], 1, "App 10: ട്രഷറിയുമായി ചെലവ് reconcile ചെയ്തശേഷം മേലുദ്യോഗസ്ഥന് അയയ്ക്കുന്നവർ.", "Reconcile with treasury before forwarding to the superior.", ["reconciliation"]),
	Q("a-35", "app", "App 13", "hard", "Replacement of an asset destroyed by flood, cyclone or fire —", [
		"is always New Service irrespective of service remaining the same",
		"need not be New Service if the service is unchanged and immediate replacement is required in public interest, irrespective of cost",
		"is charged under Art. 322",
		"must wait for the next Five Year Plan"
	], 1, "പ്രകൃതി ദുരന്തത്തിൽ നശിച്ച ആസ്തി, സേവനം മാറുന്നില്ലെങ്കിൽ, ഉടൻ പകരം — തുക എത്രയായാലും New Service അല്ല.", "Not New Service if service unchanged and immediate replacement is required.", ["new-service"]),
	Q("a-36", "app", "App 13", "hard", "Periodical revision of Dearness Allowance is —", [
		"always New Service",
		"not treated as New Service",
		"charged under Art. 229",
		"a Vote of Credit"
	], 1, "DA revision New Service അല്ല. Pay/pension scale revision Rs 25 lakh+ ആണ്.", "DA revision is not New Service.", ["new-service"]),
	Q("a-37", "app", "App 3", "medium", "Writes-off of irrecoverable loans are classified under —", [
		"Loans (object 18) only",
		"Writes-off/Losses (object 24)",
		"Suspense",
		"Secret Service"
	], 1, "Object 24: writes-off / trading losses. Write-off of loans-ന് revenue grant appropriation വേണം; New Service limit Rs 2 lakh (App 13).", "Object 24 Writes-off/Losses.", ["objects"]),
	Q("a-38", "app", "App 3", "medium", "Transfers to and from Reserve Funds are classified under —", [
		"Other Charges",
		"Inter Account Transfers",
		"Suspense",
		"Grants-in-aid"
	], 1, "Object 23 Inter Account Transfers: Reserve Funds/Deposit Accounts, capital-to-revenue write-back.", "Inter Account Transfers (object 23).", ["objects"])
];
var ch1 = [
	Q("c1-01", "ch1", "1", "easy", "The word 'budget' is derived from which French word?", [
		"bougie",
		"bougette",
		"budgetaire",
		"bourse"
	], 1, "Budget എന്ന വാക്ക് ഫ്രഞ്ച് ഭാഷയിലെ bougette-ൽ നിന്നാണ്. അർത്ഥം: ചെറിയ തുകൽ സഞ്ചി. ബ്രിട്ടീഷ് ധനമന്ത്രിമാർ പാർലമെന്റിൽ ധനനിർദേശങ്ങൾ കൊണ്ടുപോയിരുന്ന സഞ്ചിയെ ഓർമ്മിപ്പിക്കുന്നു.", "From French bougette, a small leather bag/wallet.", ["etymology", "para-1"]),
	Q("c1-02", "ch1", "1", "easy", "In the sense used today, 'budget' means —", [
		"The leather bag of the Finance Minister",
		"The Annual Financial Statement",
		"The Appropriation Act",
		"The Vote on Account"
	], 1, "ഇന്ന് budget എന്നാൽ സഞ്ചിയല്ല, അതിലുള്ള രേഖയാണ് — ധനമന്ത്രി നിയമസഭയിൽ അവതരിപ്പിക്കുന്ന Annual Financial Statement (AFS).", "Today budget means the Annual Financial Statement, not the bag.", ["afs"]),
	Q("c1-03", "ch1", "2", "easy", "Under which Article of the Constitution is the Annual Financial Statement laid before the Legislature?", [
		"Article 112",
		"Article 202",
		"Article 204",
		"Article 266"
	], 1, "ആർട്ടിക്കിൾ 202: ഓരോ സാമ്പത്തിക വർഷത്തേക്കും സംസ്ഥാനത്തിന്റെ കണക്കാക്കിയ വരവ്-ചെലവ് പ്രസ്താവന നിയമസഭയിൽ വയ്ക്കണം. ഇതാണ് AFS / Budget. (കേന്ദ്രത്തിന് Art. 112).", "Article 202(1) requires the AFS of the State to be laid before the Legislature.", ["article-202"]),
	Q("c1-04", "ch1", "3", "easy", "How many stages are there in the budgetary cycle according to the Kerala Budget Manual?", [
		"Three",
		"Four",
		"Five",
		"Six"
	], 1, "നാല് ഘട്ടങ്ങൾ: (1) Preparation (2) Passing (3) Execution (4) Review. Prep + Execution = എക്സിക്യൂട്ടീവ്. Passing + Review = നിയമസഭ.", "Four stages: Preparation, Passing, Execution, Review.", ["stages"]),
	Q("c1-05", "ch1", "3-6", "medium", "Which two budgetary stages are essentially Executive functions?", [
		"Preparation and Passing",
		"Passing and Review",
		"Preparation and Execution",
		"Execution and Review"
	], 2, "തയ്യാറാക്കലും നിർവഹണവും എക്സിക്യൂട്ടീവിന്റേത്. പാസാക്കലും അവലോകനവും നിയമസഭയുടേത് (വോട്ട്, PAC/Estimates/COPU).", "Preparation and Execution are Executive; Passing and Review are Legislative.", ["stages"]),
	Q("c1-06", "ch1", "3", "easy", "In which month does the Budget Wing of Finance Department issue the budget circular?", [
		"April",
		"June",
		"July",
		"September"
	], 2, "ഓരോ വർഷവും ജൂലൈയിൽ Budget Wing, തലവന്മാർക്കും Estimating Officers-നും സർക്കുലർ അയയ്ക്കുന്നു. ഇതാണ് Preparation-ന്റെ തുടക്കം.", "The budget circular goes out in July.", ["dates"]),
	Q("c1-07", "ch1", "3", "easy", "Non-plan estimates should reach Finance Department by —", [
		"15th August",
		"15th September",
		"30th September",
		"30th November"
	], 1, "Non-plan: സെപ്റ്റംബർ 15. Plan, Revenue: നവംബർ 30. ഈ തീയതികൾ വകുപ്പ് ടെസ്റ്റിൽ ഇടയ്ക്കിടെ വരും.", "Non-plan by 15 September; Plan and Revenue by 30 November.", ["dates", "non-plan"]),
	Q("c1-08", "ch1", "3", "easy", "Plan estimates and Revenue estimates should reach Finance Department by —", [
		"15th September",
		"1st October",
		"1st November",
		"30th November"
	], 3, "Plan, Revenue എസ്റ്റിമേറ്റുകൾ നവംബർ 30-നകം FD-യിൽ എത്തണം.", "Plan and Revenue estimates by 30 November.", ["dates", "plan"]),
	Q("c1-09", "ch1", "3", "medium", "Departmental Estimates are received direct by the Finance Department. Copies are simultaneously made available to —", [
		"The Accountant General only",
		"The Administrative Departments",
		"The Public Accounts Committee",
		"The Governor"
	], 1, "എസ്റ്റിമേറ്റ് നേരിട്ട് FD-യിലേക്ക്. കോപ്പി Administrative Department-ിനും. Admin 10 ദിവസത്തിനകം അഭിപ്രായം FD-യ്ക്ക് അയയ്ക്കും. എസ്റ്റിമേറ്റ് തന്നെ Admin-ൽ നിർത്തരുത്.", "Copies go to Administrative Departments, which comment to FD within 10 days.", ["estimates"]),
	Q("c1-10", "ch1", "3", "easy", "Administrative Departments should forward their comments on Departmental Estimates to Finance Department within —", [
		"7 days",
		"10 days",
		"15 days",
		"30 days"
	], 1, "എസ്റ്റിമേറ്റ് കിട്ടിയാൽ 10 ദിവസത്തിനകം Admin comments FD-യിലേക്ക്.", "Comments within ten days of receipt.", ["dates"]),
	Q("c1-11", "ch1", "3", "easy", "The budget is ordinarily ready for presentation to the Legislature by about —", [
		"the end of January",
		"the end of February",
		"15th March",
		"1st April"
	], 1, "പുതിയ സ്കീമുകൾക്ക് പണം നോക്കി, ബജറ്റ് ഏകദേശം ഫെബ്രുവരി അവസാനത്തോടെ അവതരണത്തിന് തയ്യാർ.", "Ready by about the end of February.", ["dates"]),
	Q("c1-12", "ch1", "4", "easy", "Who presents the budget to the Legislature?", [
		"The Governor in person",
		"The Finance Minister",
		"The Chief Secretary",
		"The Accountant General"
	], 1, "ധനമന്ത്രിയാണ് ബജറ്റ് അവതരിപ്പിക്കുന്നത് — സാധാരണ ഫെബ്രുവരി അവസാനം / മാർച്ച് ആദ്യം. അവതരണ ദിവസം ഗവർണർ നിശ്ചയിക്കുന്നു (പിന്നീടുള്ള അധ്യായം).", "Presented by the Finance Minister towards end of February or beginning of March.", ["passing"]),
	Q("c1-13", "ch1", "4", "easy", "A Demand for Grant is, in effect —", [
		"an order of the Accountant General",
		"a request from the Executive to the Legislature for a specified sum",
		"a charged appropriation that is not voted",
		"a letter of credit"
	], 1, "Demand for Grant = ഒരു സേവനത്തിന് ആ വർഷം വേണ്ട തുകയ്ക്ക് എക്സിക്യൂട്ടീവ് നിയമസഭയോട് ചെയ്യുന്ന അപേക്ഷ.", "A request from the Executive to the Legislature for a specified sum for a service.", ["demand"]),
	Q("c1-14", "ch1", "4", "easy", "The legal authority for withdrawal of money from the Consolidated Fund of the State is —", [
		"The budget speech",
		"The Annual Financial Statement",
		"The Appropriation Act",
		"The Finance Department circular"
	], 2, "നിയമസഭ വോട്ട് ചെയ്തതുകൊണ്ട് മാത്രം പണം എടുക്കാൻ പറ്റില്ല. Appropriation Act ആണ് Consolidated Fund-ൽ നിന്ന് പിൻവലിക്കാനുള്ള നിയമാധികാരം. ഓരോ സേവനത്തിനും പരമാവധി തുകയും ഇതിൽ.", "The Appropriation Act is the legal authority to withdraw from the Consolidated Fund.", ["appropriation-act"]),
	Q("c1-15", "ch1", "5", "medium", "Publication of the Appropriation Act in the Government Gazette is —", [
		"only a publicity measure",
		"sufficient authority for payment and appropriation of the sums included therein",
		"not valid until AG countersigns",
		"valid only after PAC approval"
	], 1, "ആക്ട് ഗസറ്റിൽ വന്നാൽ തന്നെ അതിലെ തുകകൾ അടയ്ക്കാനും appropriation ചെയ്യാനും മതിയായ അധികാരം. FD ഇക്കാര്യം സർക്കുലറായി അറിയിക്കും.", "Gazette publication is sufficient authority for payment and appropriation.", ["gazette"]),
	Q("c1-16", "ch1", "5", "medium", "Distribution of appropriation normally flows in which order?", [
		"Disbursing Officer → Chief Controlling Officer → Finance Department",
		"Chief Controlling Officer → Sub-controlling Officer → Disbursing Officer",
		"Accountant General → Treasury → Disbursing Officer",
		"Governor → Finance Minister → Heads of Departments"
	], 1, "CCO ആദ്യം തുക വിഭജിക്കുന്നു. SCO അടുത്ത നിരയ്ക്ക്. DO ചെലവഴിക്കുന്നു. ചിലപ്പോൾ CCO/SCO തുക സ്വന്തം കൈയിൽ നിർത്തും.", "CCO distributes to SCOs/DOs; SCOs divide among Disbursing Officers.", ["control"]),
	Q("c1-17", "ch1", "5", "medium", "If the budget grant cannot be utilised in full, excess funds are surrendered —", [
		"direct to the Treasury",
		"in the reverse order in which they were received, finally resumed by Finance Department",
		"only after PAC permission",
		"to the Contingency Fund"
	], 1, "സറണ്ടർ ലഭിച്ച ക്രമത്തിന്റെ വിപരീതമായി: DO → SCO → CCO → FD റിസ്യൂം ചെയ്യുന്നു.", "Surrendered in reverse order; FD resumes the final savings.", ["surrender"]),
	Q("c1-18", "ch1", "6", "easy", "After the close of the year, accounts are audited by an independent authority, namely —", [
		"The Finance Department",
		"The Comptroller and Auditor General",
		"The Public Service Commission",
		"The Estimates Committee"
	], 1, "എക്സിക്യൂട്ടീവ് ചെലവഴിച്ചത് ഉദ്ദേശിച്ച ആവശ്യത്തിന്, ഉദ്ദേശിച്ച തുകയിൽ തന്നെയാണോ എന്ന് CAG ഓഡിറ്റ് ചെയ്യുന്നു. റിപ്പോർട്ട് PAC/COPU പരിശോധിക്കുന്നു.", "Audited by the CAG; examined by PAC/COPU. Estimates Committee examines estimates.", ["cag", "review"]),
	Q("c1-19", "ch1", "6", "medium", "Detailed examination of the Estimates to see how plans can be executed efficiently and economically is entrusted to —", [
		"Public Accounts Committee",
		"Estimates Committee",
		"Committee on Public Undertakings",
		"Finance Department"
	], 1, "Estimates Committee: ബജറ്റ് എസ്റ്റിമേറ്റ് എങ്ങനെ ലാഭകരമായും കാര്യക്ഷമമായും നടത്താം. PAC അക്കൗണ്ട്/ഓഡിറ്റ് നോക്കുന്നു. രണ്ടും വേറെ.", "The Estimates Committee examines estimates for economy and efficiency.", ["estimates-committee"]),
	Q("c1-20", "ch1", "7", "easy", "The present structure of budget and accounts came into force from —", [
		"1 April 1961",
		"1 April 1968",
		"1 April 1974",
		"1 April 1977"
	], 2, "GOI Study Team-ന്റെ ശുപാർശപ്രകാരം 1974 ഏപ്രിൽ 1 മുതൽ പുതിയ ഘടന. അഞ്ച് തട്ട് വർഗീകരണം ഇതോടെ.", "Reforms from 1 April 1974.", ["1974"]),
	Q("c1-21", "ch1", "8", "easy", "Government accounts are kept in how many parts?", [
		"Two",
		"Three",
		"Four",
		"Five"
	], 1, "മൂന്ന് ഭാഗം: Part I Consolidated Fund, Part II Contingency Fund, Part III Public Account.", "Three parts: Consolidated Fund, Contingency Fund, Public Account.", ["accounts"]),
	Q("c1-22", "ch1", "8", "easy", "Part I of Government accounts is —", [
		"Contingency Fund",
		"Public Account",
		"Consolidated Fund",
		"Suspense Account"
	], 2, "Part I = Consolidated Fund (Art. 266). ഇവിടെ നിന്ന് പണം എടുക്കാൻ Appropriation Act വേണം.", "Part I is the Consolidated Fund.", ["consolidated-fund"]),
	Q("c1-23", "ch1", "8", "medium", "The Consolidated Fund has two main divisions. They are —", [
		"Voted and Charged",
		"Plan and Non-plan",
		"Revenue; and Capital, Public Debt, Loans etc.",
		"Receipts and Recoveries"
	], 2, "CF-ന് രണ്ട് ഡിവിഷൻ: (1) Revenue (2) Capital, Public debt, loans etc. Charged/Voted ഒരു വേറെ വേർതിരിവ്.", "Revenue; and Capital, Public debt, loans etc.", ["consolidated-fund"]),
	Q("c1-24", "ch1", "8", "medium", "Transactions of the Contingency Fund are recorded in —", [
		"Part I",
		"Part II",
		"Part III",
		"Appendix 3"
	], 1, "Part II = Contingency Fund. Art. 267(2) പ്രകാരം നിയമസഭ സ്ഥാപിക്കുന്നു. അടിയന്തര ചെലവിന് ഗവർണറുടെ imprest.", "Part II records Contingency Fund transactions (Art. 267(2)).", ["contingency-fund"]),
	Q("c1-25", "ch1", "8", "medium", "The Contingency Fund of the State is established under —", [
		"Article 202",
		"Article 266(1)",
		"Article 267(2)",
		"Article 283"
	], 2, "Art. 267(2) = സംസ്ഥാന Contingency Fund. (കേന്ദ്രം 267(1)). കേരളത്തിൽ Kerala Contingency Fund Act, 1957.", "Article 267(2) for the State Contingency Fund.", ["article-267"]),
	Q("c1-26", "ch1", "8", "medium", "Part III of Government accounts — the Public Account — records transactions relating to —", [
		"Tax revenue only",
		"Debt (other than in Part I), Deposits, Advances, Remittances and Suspense",
		"Capital works only",
		"Charged expenditure only"
	], 1, "Public Account: Debt (Part I-ൽ ഇല്ലാത്തത്), Deposits, Advances, Remittances, Suspense. നിയമസഭാ വോട്ട് വേണ്ട; സർക്കാർ ബാങ്കറാണ്.", "Debt (other than Part I), Deposits, Advances, Remittances and Suspense.", ["public-account"]),
	Q("c1-27", "ch1", "9", "easy", "From 1974-75, transactions are classified according to a —", [
		"three-tier system",
		"four-tier system",
		"five-tier system",
		"six-tier system"
	], 2, "അഞ്ച് തട്ട്: Sector → Major Head → Minor Head → Sub-head → Detailed Head. ലക്ഷ്യം: വകുപ്പിനേക്കാൾ പ്രവർത്തന/ഒബ്ജക്റ്റ് കേന്ദ്രീകൃത വർഗീകരണം.", "Five-tier system from 1974-75.", ["classification"]),
	Q("c1-28", "ch1", "9", "easy", "The first tier of classification is the —", [
		"Major head",
		"Sector",
		"Detailed head",
		"Grant"
	], 1, "ഒന്നാം തട്ട് Sector — ഗവൺമെന്റ് പ്രവർത്തനങ്ങളുടെ വിശാല ഗ്രൂപ്പ്. ഉദാ: A. Tax Revenue, B. Social and Community Services.", "Sector is the first tier.", ["sector"]),
	Q("c1-29", "ch1", "9", "easy", "The main unit of classification in the accounts, forming the second tier, is the —", [
		"Minor head",
		"Major head",
		"Sub-head",
		"Detailed head"
	], 1, "Major head = രണ്ടാം തട്ട് = function (Education, Medical, Housing). അക്കൗണ്ടിലെ പ്രധാന യൂണിറ്റ്.", "Major head is the second tier and the main unit of classification.", ["major-head"]),
	Q("c1-30", "ch1", "9", "easy", "Minor heads generally identify —", [
		"the object of expenditure such as salaries",
		"programmes undertaken to achieve the objectives of a function",
		"the department which spends",
		"the treasury of payment"
	], 1, "Minor head = മൂന്നാം തട്ട് = programme. ഉദാ: Public Health-ന് കീഴിൽ Prevention and control of diseases.", "Minor heads identify programmes under a function.", ["minor-head"]),
	Q("c1-31", "ch1", "9", "easy", "Sub-heads generally reflect —", [
		"sectors of the economy",
		"schemes or activities under a programme",
		"standard objects like wages",
		"the Consolidated Fund"
	], 1, "Sub-head = നാലാം തട്ട് = scheme/activity. ഉദാ: National Malaria Eradication Programme.", "Sub-heads = schemes or activities under a programme.", ["sub-head"]),
	Q("c1-32", "ch1", "9", "easy", "The fifth and last tier of classification, otherwise known as object classification, is the —", [
		"Sector",
		"Minor head",
		"Detailed head",
		"Demand for Grant"
	], 2, "Detailed head = അഞ്ചാം തട്ട് = object: Salaries, Wages, Office Expenses തുടങ്ങിയ inputs. വകുപ്പുതല നിയന്ത്രണത്തിന് ഇത്.", "Detailed head is the fifth tier (object classification).", ["detailed-head"]),
	Q("c1-33", "ch1", "9", "hard", "For the function 'Housing', the major head numbers in Revenue Receipts, Revenue Expenditure, Capital Expenditure and Loans typically differ from each other by —", [
		"100",
		"150",
		"200",
		"400"
	], 2, "Housing ഉദാഹരണം: 083, 283, 483, 683. അവസാന രണ്ട് അക്കം ഒന്നുതന്നെ (33); എണ്ണം 200-ൽ കൂടുന്നു. ആദ്യ അക്കം സെക്ഷൻ കാണിക്കുന്നു.", "Corresponding functional heads differ by 200 (e.g. 083, 283, 483, 683).", ["coding"]),
	Q("c1-34", "ch1", "9", "medium", "The only major head in Part II — Contingency Fund — bears the number —", [
		"400",
		"600",
		"800",
		"900"
	], 2, "Contingency Fund major head = 800. Public Account = 801–899.", "Major head 800 for Contingency Fund.", ["coding"]),
	Q("c1-35", "ch1", "9", "medium", "Introduction of a new major or minor head requires the approval of —", [
		"Finance Department alone",
		"The Comptroller and Auditor General of India (who will obtain the President's approval where necessary)",
		"The Public Accounts Committee",
		"The State Legislature by a simple motion"
	], 1, "പുതിയ major/minor head, പേര് മാറ്റം, നീക്കം — CAG അംഗീകാരം. ആവശ്യമെങ്കിൽ രാഷ്ട്രപതി. Sub-head സംസ്ഥാനവും AG-യും തീരുമാനിക്കാം.", "New major/minor heads need CAG approval (and President where necessary).", ["heads"]),
	Q("c1-36", "ch1", "9", "medium", "A list of standard detailed heads (objects of expenditure) is given in —", [
		"Appendix 1",
		"Appendix 2",
		"Appendix 3",
		"Appendix 4"
	], 2, "App 3 = Standard objects (26 എണ്ണം: Salaries മുതൽ Other Charges വരെ). App 2 = Major/Minor heads (പ്രത്യേക വാല്യം). App 4 = Charged items.", "Appendix 3 lists standard detailed heads.", ["appendix-3"]),
	Q("c1-37", "ch1", "9", "medium", "Sectors in the Revenue Receipts section are —", [
		"A. General Services, B. Social Services, C. Economic Services",
		"A. Tax Revenue, B. Non-tax Revenue, C. Grants-in-aid and Contributions",
		"E. Public Debt, F. Loans",
		"I. Small Savings, J. Reserve Funds"
	], 1, "റവന്യൂ വരവ്: A Tax, B Non-tax, C Grants. റവന്യൂ ചെലവ്: A General, B Social and Community, C Economic, D Grants.", "Revenue receipts: A Tax, B Non-tax, C Grants-in-aid and Contributions.", ["sectors"]),
	Q("c1-38", "ch1", "10", "easy", "Expenditure subject to the vote of the Legislature should be shown in the accounts separately from expenditure that is —", [
		"plan expenditure",
		"charged on the Consolidated Fund",
		"recovered from other departments",
		"met from the Public Account"
	], 1, "Charged (voted അല്ല) App 4 / Art. 202(3) പ്രകാരം. Charged ചർച്ച ചെയ്യാം, വോട്ട് ചെയ്യരുത്. അക്കൗണ്ടിൽ വേറെ കാണിക്കണം.", "Voted and charged expenditure are shown separately. Charged list: Appendix 4.", ["charged"]),
	Q("c1-39", "ch1", "Preface", "medium", "The first edition of the Kerala Budget Manual was published in —", [
		"March 1956",
		"March 1966",
		"April 1977",
		"March 1985"
	], 1, "ഒന്നാം പതിപ്പ് മാർച്ച് 1966, C. Thomas, Special Secretary (Finance). Travancore-Cochin Budget Manual പകരം.", "First edition: March 1966 (C. Thomas).", ["preface"]),
	Q("c1-40", "ch1", "Preface", "medium", "The first Performance Budget in Kerala was prepared in —", [
		"1968-69 for the Secretariat",
		"1970-71 for PWD (Buildings and Roads)",
		"1974-75 for all departments",
		"1976-77 for agency subjects"
	], 1, "ARC 1968 ശുപാർശ. കേരളം ആദ്യം 1970-71 PWD (B&R). തിരഞ്ഞെടുത്ത വകുപ്പുകൾക്ക് പിന്നീട് വർഷംതോറും.", "First Performance Budget: 1970-71, PWD (B&R).", ["performance"]),
	Q("c1-41", "ch1", "Preface", "medium", "The Committee on Public Undertakings was constituted in Kerala in —", [
		"March 1966",
		"November 1968",
		"April 1974",
		"April 1977"
	], 1, "COPU: 1968 നവംബർ. Appropriation Control, Letter of Credit: 1974-75. Agency subject മാറ്റം: 1976-77.", "COPU constituted in November 1968.", ["copu"]),
	Q("c1-42", "ch1", "Preface", "medium", "The system of Appropriation Control and the system of Letter of Credit were adopted in —", [
		"1966-67",
		"1970-71",
		"1974-75",
		"1980-81"
	], 2, "രണ്ടും 1974-75-ൽ. LoC ആദ്യം PWD, PHE, Forest. Appropriation Control 15 വകുപ്പുകളിൽ.", "Both systems from 1974-75.", ["loc", "appropriation-control"]),
	Q("c1-43", "ch1", "9", "hard", "Major heads in the Revenue Receipts Section are assigned the block of numbers —", [
		"020 to 199",
		"211 to 399",
		"411 to 599",
		"801 to 899"
	], 0, "റവന്യൂ വരവ് 020–199, റവന്യൂ ചെലവ് 211–399, ക്യാപിറ്റൽ ചെലവ് 411–599, Public Debt/Loans 601–799, CF 800, Public Account 801–899.", "Revenue receipts: 020–199.", ["coding"]),
	Q("c1-44", "ch1", "9", "medium", "Sub-sectors, where used, are distinguished by —", [
		"capital letters of the alphabet",
		"small letters of the alphabet",
		"three-digit codes",
		"Roman numerals"
	], 1, "Sector = വലിയക്ഷരം (A, B, C). Sub-sector = ചെറിയക്ഷരം (a, b, c). ഉദാ: A. General Services (a) Organs of State.", "Sub-sectors use small letters; sectors use capital letters.", ["sector"]),
	Q("c1-45", "ch1", "8", "hard", "Capital expenditure is met usually from borrowed funds with the object of —", [
		"meeting salaries of the year",
		"increasing concrete assets of a material and permanent character, or reducing recurring liabilities",
		"granting ways and means advances only",
		"paying interest on public debt"
	], 1, "ക്യാപിറ്റൽ ചെലവ്: സ്ഥിര ആസ്തി (ഉദാ ഡാം) വർധിപ്പിക്കുക അല്ലെങ്കിൽ ആവർത്തന ബാധ്യത കുറയ്ക്കുക. സാധാരണ കടം മുതൽ.", "Capital outlay: lasting assets or reducing recurring liabilities, usually from borrowed funds.", ["capital"])
];
var ch10 = [
	Q("c10-01", "ch10", "108", "easy", "The Public Accounts Committee consists of —", [
		"7 members",
		"11 members",
		"15 members",
		"21 members"
	], 1, "PAC: 11 അംഗങ്ങൾ. Rules 231–232. STV proportional. 2 വർഷം. മന്ത്രി അംഗമാകരുത്.", "11 members, Rules 231–232.", ["pac"]),
	Q("c10-02", "ch10", "108", "easy", "The term of the PAC is —", [
		"one year",
		"two years",
		"five years",
		"during the pleasure of the Governor"
	], 1, "2 വർഷം. Estimates Committee, COPU-ഉം 11 അംഗം, 2 വർഷം — താരതമ്യ ചോദ്യം.", "Two years.", ["pac"]),
	Q("c10-03", "ch10", "108", "easy", "A Minister —", [
		"is always the Chairman of PAC",
		"shall not be a member of the PAC",
		"must attend every sitting as a member",
		"nominates all 11 members personally"
	], 1, "മന്ത്രി PAC/Estimates/COPU അംഗമല്ല. എക്സിക്യൂട്ടീവിനെ സഭ പരിശോധിക്കുന്ന കമ്മിറ്റി.", "No Minister on PAC.", ["pac"]),
	Q("c10-04", "ch10", "108", "easy", "Members of PAC are elected according to the principle of proportional representation by means of —", [
		"first-past-the-post",
		"single transferable vote",
		"lot",
		"nomination by CAG"
	], 1, "STV proportional representation — മൂന്ന് ധനകാര്യ കമ്മിറ്റികൾക്കും.", "Single transferable vote (proportional representation).", ["pac"]),
	Q("c10-05", "ch10", "108", "medium", "PAC examines —", [
		"day-to-day administration of public undertakings in the Fourth Schedule",
		"Appropriation Accounts, Finance Accounts and CAG reports (other than those of Fourth Schedule undertakings, which go to COPU)",
		"only the budget speech",
		"only charged expenditure of the Governor"
	], 1, "PAC: Appropriation Accounts, Finance Accounts, CAG reports. Fourth Schedule undertakings → COPU.", "Appropriation Accounts, Finance Accounts, CAG reports — not Fourth Schedule undertakings.", ["pac"]),
	Q("c10-06", "ch10", "108", "medium", "PAC particularly looks into whether —", [
		"the Estimates Committee toured enough",
		"money was legally available, spent on the service, with authority, and reappropriation was in order, and excesses",
		"the Governor signed every bill",
		"Part II schemes were printed in Malayalam"
	], 1, "നിയമപരമായി പണം ഉണ്ടായിരുന്നോ, ആ സേവനത്തിന് ചെലവഴിച്ചോ, അധികാരമുണ്ടോ, reappropriation നിയമാനുസൃതമോ, excess ഉണ്ടോ.", "Legal availability, authority, purpose, reappropriation, excesses.", ["pac"]),
	Q("c10-07", "ch10", "108", "medium", "Minutes of dissent in the PAC —", [
		"are the normal practice",
		"are not allowed",
		"must be signed by the CAG",
		"replace the report"
	], 1, "PAC-യിൽ dissent minutes ഇല്ല. ഏകാഭിപ്രായ റിപ്പോർട്ട്.", "No minutes of dissent.", ["pac"]),
	Q("c10-08", "ch10", "108", "medium", "Who are present at all PAC meetings?", [
		"The Governor and the Chief Justice",
		"Finance Secretary, Administrative Secretary concerned, and the Accountant General",
		"All Disbursing Officers of the State",
		"The Estimates Committee in full"
	], 1, "Finance Secretary, ബന്ധപ്പെട്ട Admin Secretary, AG — എല്ലാ മീറ്റിംഗിലും.", "Finance Secretary, Admin Secretary, AG.", ["pac"]),
	Q("c10-09", "ch10", "108", "hard", "The Speaker has authorised PAC to examine accounts even before they are laid, but —", [
		"the report may still be presented to the House before laying",
		"no report shall be made to the House before the accounts/reports are laid (Art. 151(2))",
		"PAC may publish in newspapers first",
		"CAG need not audit"
	], 1, "പരിശോധന മുമ്പ് തുടങ്ങാം; സഭയ്ക്ക് റിപ്പോർട്ട് Art. 151(2) പ്രകാരം വച്ചതിന് ശേഷം മാത്രം.", "No report to the House before laying under Article 151(2).", ["pac"]),
	Q("c10-10", "ch10", "108", "hard", "Notes for PAC are typically prepared in —", [
		"3 copies only for the Minister",
		"30 copies, of which 3 go to the Accountant General",
		"one copy to the press",
		"100 copies to every DO"
	], 1, "30 കോപ്പി നോട്ട്; 3 AG-യ്ക്ക്. App 15.", "30 copies of notes; 3 to AG.", ["pac"]),
	Q("c10-11", "ch10", "108", "easy", "PAC is constituted under Assembly Rules —", [
		"231–232",
		"233–235",
		"236–237",
		"only Appendix 17"
	], 0, "PAC 231–232; Estimates 233–235; COPU 236–237. ക്രമം ഓർക്കുക.", "Rules 231–232.", ["pac"])
];
var ch11 = [
	Q("c11-01", "ch11", "109", "easy", "The Estimates Committee consists of —", [
		"9 members for one year",
		"11 members for two years",
		"15 members nominated by CAG",
		"all MLAs"
	], 1, "Estimates Committee-ഉം 11 അംഗം, 2 വർഷം, STV, മന്ത്രി ഇല്ല. Rules 233–235.", "11 members, two years, Rules 233–235.", ["estimates-committee"]),
	Q("c11-02", "ch11", "109", "easy", "The Estimates Committee is concerned with —", [
		"Appropriation Accounts of past years only",
		"economy, alternative policies, whether money is well laid out, and the form of estimates",
		"day-to-day management of companies",
		"issuing letters of credit"
	], 1, "സമ്പദ്‌വ്യവസ്ഥ, ബദൽ നയം, പണം നന്നായി ഉപയോഗിക്കുന്നുണ്ടോ, എസ്റ്റിമേറ്റിന്റെ രൂപം.", "Economy, alternative policies, value for money, form of estimates.", ["estimates-committee"]),
	Q("c11-03", "ch11", "109", "medium", "The Estimates Committee —", [
		"must examine the entire estimates before any demand is voted",
		"need not examine the entire estimates; demands may be voted without its report",
		"passes the Appropriation Act",
		"replaces PAC"
	], 1, "മുഴുവൻ എസ്റ്റിമേറ്റ് നോക്കണമെന്നില്ല. റിപ്പോർട്ടില്ലാതെയും demands വോട്ട് ചെയ്യാം.", "Need not cover the whole estimates; voting need not wait for its report.", ["estimates-committee"]),
	Q("c11-04", "ch11", "109", "medium", "On equality of votes in the Estimates Committee, the Chairman has —", [
		"no vote",
		"a casting vote",
		"two deliberative votes",
		"to refer to the Governor"
	], 1, "സമനിലയിൽ Chairman-ന് casting vote.", "Casting vote of the Chairman.", ["estimates-committee"]),
	Q("c11-05", "ch11", "109", "medium", "An advance report of the Estimates Committee is —", [
		"public immediately",
		"secret until presented to the House",
		"sent only to CAG",
		"published in the Gazette as an Act"
	], 1, "അവതരിപ്പിക്കും വരെ രഹസ്യം.", "Secret until presented.", ["estimates-committee"]),
	Q("c11-06", "ch11", "109", "easy", "Estimates Committee is governed by Rules —", [
		"231–232",
		"233–235",
		"236–237",
		"Article 267 only"
	], 1, "233–235 = Estimates Committee.", "Rules 233–235.", ["estimates-committee"]),
	Q("c11-07", "ch11", "109", "easy", "A Minister shall not be a member of —", [
		"PAC only",
		"Estimates Committee only",
		"PAC, Estimates Committee and COPU",
		"the Cabinet"
	], 2, "മൂന്ന് ധനകാര്യ കമ്മിറ്റികളിലും മന്ത്രി അംഗമല്ല.", "None of the three financial committees includes a Minister.", ["committees"])
];
var ch12 = [
	Q("c12-01", "ch12", "110", "easy", "The Committee on Public Undertakings was first constituted in Kerala in —", [
		"March 1966",
		"November 1968",
		"April 1974",
		"April 1977"
	], 1, "COPU: 1968 നവംബർ. Rules 236–237. 11 അംഗം, 2 വർഷം.", "November 1968.", ["copu"]),
	Q("c12-02", "ch12", "110", "easy", "COPU consists of —", [
		"11 members elected for two years",
		"21 members nominated by the CM",
		"the PAC sitting jointly with Estimates",
		"CAG's staff only"
	], 0, "11, 2 വർഷം, STV, മന്ത്രി ഇല്ല — PAC/Estimates പോലെ.", "11 members, two years.", ["copu"]),
	Q("c12-03", "ch12", "110", "easy", "COPU examines reports and accounts of undertakings listed in —", [
		"Appendix 3",
		"Appendix 8",
		"the Fourth Schedule (Appendix 16)",
		"Appendix 4"
	], 2, "Fourth Schedule undertakings = App 16. CAG reports on them-ഉം COPU നോക്കുന്നു.", "Fourth Schedule / Appendix 16.", ["copu"]),
	Q("c12-04", "ch12", "110", "medium", "A public undertaking, for this purpose, generally means a concern with —", [
		"any share held by Government",
		"not less than 51% of paid-up capital held by the State, plus statutory corporations/boards",
		"100% private capital",
		"only departmental wings"
	], 1, "51%+ paid-up capital സംസ്ഥാനം; statutory corporations/boards-ഉം.", "≥51% State paid-up capital, and statutory corporations/boards.", ["copu"]),
	Q("c12-05", "ch12", "110", "medium", "COPU shall not examine —", [
		"whether the undertaking is run on sound business principles",
		"major Government policy, day-to-day administration, or matters of special statutory machinery",
		"CAG reports on those undertakings",
		"accounts in the Fourth Schedule"
	], 1, "നോക്കില്ല: വലിയ ഗവൺമെന്റ് നയം, ദിനംപ്രതി ഭരണം, പ്രത്യേക statutory machinery. നോക്കും: sound business principles, accounts, CAG reports.", "Not major policy, day-to-day admin, or special statutory machinery.", ["copu"]),
	Q("c12-06", "ch12", "110", "easy", "COPU works under Assembly Rules —", [
		"231–232",
		"233–235",
		"236–237",
		"Article 202 only"
	], 2, "236–237 = COPU.", "Rules 236–237.", ["copu"]),
	Q("c12-07", "ch12", "110", "medium", "Which committee examines CAG reports on public undertakings in the Fourth Schedule?", [
		"PAC",
		"Estimates Committee",
		"COPU",
		"Business Advisory Committee"
	], 2, "Fourth Schedule → COPU, PAC അല്ല. മറ്റ് CAG reports → PAC.", "COPU, not PAC.", ["copu"]),
	Q("c12-08", "ch12", "110", "easy", "List of Public Undertakings is given in —", [
		"Appendix 9",
		"Appendix 13",
		"Appendix 16",
		"Appendix 17"
	], 2, "App 16 = List of Public Undertakings.", "Appendix 16.", ["copu"])
];
var ch2 = [
	Q("c2-01", "ch2", "11", "easy", "A Chief Controlling Officer is ordinarily —", [
		"any Disbursing Officer",
		"the Head of a Department or the Secretary of an Administrative Department",
		"the Treasury Officer",
		"the Accountant General"
	], 1, "CCO സാധാരണ Head of Department അല്ലെങ്കിൽ Administrative Department-ിന്റെ സെക്രട്ടറി. ഗ്രാന്റിന്റെ മൊത്തം നിയന്ത്രണം ഇദ്ദേഹത്തിന്.", "CCO is ordinarily the HoD or the Secretary of an Administrative Department.", ["cco"]),
	Q("c2-02", "ch2", "11", "easy", "From 1974-75, the unit of appropriation is —", [
		"the major head",
		"the minor head",
		"the detailed head",
		"the sector"
	], 2, "1974-75 മുതൽ unit of appropriation = detailed head (ഉണ്ടെങ്കിൽ). ഇല്ലെങ്കിൽ sub-head / minor head. ഒരു യൂണിറ്റിൽ കവിഞ്ഞാൽ അതാണ് excess — ഗ്രാന്റ് മൊത്തം മിച്ചമുണ്ടെങ്കിലും.", "Unit of appropriation is the detailed head from 1974-75.", ["unit"]),
	Q("c2-03", "ch2", "11", "easy", "Reappropriation means —", [
		"taking an advance from the Contingency Fund",
		"transfer of funds from one unit of appropriation to another within the same grant",
		"surrender of savings to Finance Department",
		"voting a supplementary grant"
	], 1, "ഒരേ ഗ്രാന്റിനുള്ളിൽ ഒരു unit of appropriation-ൽ നിന്ന് മറ്റൊന്നിലേക്ക് തുക മാറ്റുന്നതാണ് reappropriation. ഗ്രാന്റുകൾക്കിടയിൽ പറ്റില്ല.", "Transfer of funds between units of appropriation within the same grant.", ["reappropriation"]),
	Q("c2-04", "ch2", "11", "medium", "Surrender of savings is made —", [
		"direct to the Accountant General",
		"through the Administrative Department to the Finance Department",
		"to the Contingency Fund",
		"only after the Appropriation Accounts are printed"
	], 1, "മിച്ചം Admin Department വഴി FD-യ്ക്ക് സറണ്ടർ. FD സ്വീകരിച്ച് റിസ്യൂം ചെയ്യുമ്പോൾ അത് resumption.", "Surrender through Administrative Department to Finance Department.", ["surrender"]),
	Q("c2-05", "ch2", "11", "medium", "Resumption of funds means —", [
		"reappropriation by the CCO",
		"acceptance by Finance Department of savings surrendered, taking them to Government account",
		"an advance from Contingency Fund",
		"an excess grant after the year"
	], 1, "സറണ്ടർ ചെയ്ത മിച്ചം FD സ്വീകരിച്ച് ഗവൺമെന്റ് അക്കൗണ്ടിലേക്ക് എടുക്കുന്നതാണ് resumption. പിന്നീട് ആവശ്യമെങ്കിൽ FD റദ്ദാക്കാം.", "FD's acceptance of surrendered savings, taking them to Government account.", ["resumption"]),
	Q("c2-06", "ch2", "11", "easy", "A 'New Service' is one not contemplated in the Annual Financial Statement, attracting —", [
		"Article 112 only",
		"Article 205 (and corresponding Art. 115 at the Centre)",
		"Article 266 only",
		"Article 283"
	], 1, "AFS-ൽ കാണാത്ത പുതിയ സേവനം = New Service. Art. 205 പ്രകാരം സപ്ലിമെന്ററി/വോട്ട് വേണം. മാനദണ്ഡം PAC/App 13.", "New Service: not contemplated in the AFS; Article 205.", ["new-service"]),
	Q("c2-07", "ch2", "11", "easy", "An 'excess grant' is voted —", [
		"before the year begins",
		"during the year along with the budget",
		"after the close of the financial year, to regularise excess expenditure",
		"only for charged items"
	], 2, "വർഷം കഴിഞ്ഞശേഷം, പരിധി കവിഞ്ഞ ചെലവ് regularise ചെയ്യാൻ Art. 205 പ്രകാരം excess grant. ഇത് ക്രമക്കേടാണ്; നടപടി App 15.", "Voted after the close of the year to regularise excess over grant.", ["excess"]),
	Q("c2-08", "ch2", "11", "easy", "A major work, as defined in the Manual, is a work costing more than —", [
		"Rs 10,000",
		"Rs 25,000",
		"Rs 1 lakh",
		"Rs 5 lakh"
	], 2, "Major work > Rs 1 lakh. Minor work ≤ Rs 1 lakh. (KPWA Code വഴിയും ഇത് ബന്ധപ്പെടുന്നു).", "Major work: costing more than Rs 1 lakh. Minor work: not more than Rs 1 lakh.", ["works"]),
	Q("c2-09", "ch2", "11", "easy", "A minor work is a work costing —", [
		"not more than Rs 1 lakh",
		"not more than Rs 10,000",
		"more than Rs 1 lakh",
		"exactly Rs 2,500"
	], 0, "Minor work: ഒരു ലക്ഷം രൂപയോ അതിൽ കുറവോ.", "Minor work ≤ Rs 1 lakh.", ["works"]),
	Q("c2-10", "ch2", "11", "medium", "Appropriation means —", [
		"the assignment of a specified sum by the Legislature to meet specified expenditure",
		"the transfer of savings from one grant to another",
		"the cash balance in treasuries",
		"the vote on account"
	], 0, "നിയമസഭ ഒരു നിശ്ചിത ചെലവിന് നിശ്ചിത തുക അനുവദിക്കുന്നതാണ് appropriation. Appropriation Act ഇതിന് നിയമരൂപം നൽകുന്നു.", "Assignment of a specified sum by the Legislature to meet specified expenditure.", ["appropriation"]),
	Q("c2-11", "ch2", "11", "medium", "A 'Grant' means —", [
		"any reappropriation order",
		"the sum voted by the Legislature in respect of a demand, together with charged appropriations under the same demand where relevant",
		"only charged expenditure",
		"Contingency Fund advance"
	], 1, "ഗ്രാന്റ് = ഒരു Demand-ന് നിയമസഭ വോട്ട് ചെയ്ത തുക (ബന്ധപ്പെട്ട charged appropriation ഉം ചേർത്ത് മനസ്സിലാക്കാം). ഓരോ Demand-ും പ്രത്യേക ഗ്രാന്റ്.", "The sum voted by the Legislature on a Demand for Grant.", ["grant"]),
	Q("c2-12", "ch2", "11", "medium", "Voted expenditure is expenditure —", [
		"charged on the Consolidated Fund",
		"submitted to the vote of the Legislature",
		"met from the Public Account",
		"always of a capital nature"
	], 1, "Voted = നിയമസഭയുടെ വോട്ടിന് വിധേയം. Charged = വോട്ട് വേണ്ട, ചർച്ച ചെയ്യാം.", "Voted expenditure is submitted to the vote of the Legislature.", ["voted"]),
	Q("c2-13", "ch2", "11", "medium", "Budget Estimates are the detailed estimates of receipts and expenditure —", [
		"of the current year after five months",
		"included in the budget for a financial year",
		"prepared only after the Appropriation Act",
		"of the previous three years' average only"
	], 1, "BE = ആ സാമ്പത്തിക വർഷത്തെ ബജറ്റിൽ ഉൾപ്പെടുത്തിയ വിശദ എസ്റ്റിമേറ്റ്. RE അതല്ല — നടപ്പ് വർഷത്തെ പുതുക്കിയ കണക്ക്.", "Detailed estimates included in the budget for a financial year.", ["be"]),
	Q("c2-14", "ch2", "11", "medium", "Revised Estimate is —", [
		"legal authority to spend more than the grant",
		"an estimate of the probable receipts or expenditure of the current year, based on actuals and a review of remaining months",
		"the next year's Budget Estimate",
		"an excess grant"
	], 1, "RE = നടപ്പ് വർഷത്തെ സാധ്യതയുള്ള വരവ്/ചെലവ്. അധിക ചെലവിന് അധികാരമല്ല; ഗ്രാന്റ് കുറയ്ക്കുന്നുമില്ല. അടുത്ത BE-യ്ക്ക് മികച്ച ഗൈഡ്.", "RE forecasts current-year probable figures; it does not authorise extra spend.", ["re"]),
	Q("c2-15", "ch2", "11", "hard", "Distribution of funds means —", [
		"reappropriation between grants",
		"dividing a lump provision among units of appropriation",
		"surrender to Finance Department",
		"vote on account"
	], 1, "ലമ്പ് പ്രൊവിഷൻ unit of appropriation-ുകൾക്ക് വിഭജിക്കുന്നതാണ് distribution of funds.", "Dividing a lump provision among units of appropriation.", ["distribution"]),
	Q("c2-16", "ch2", "11", "medium", "An 'Agency subject' is a Union subject administered by the State —", [
		"as if it were a State subject, with receipts and expenditure in the State section (subject to later changes noted in the Manual)",
		"only through the Contingency Fund",
		"without any estimate",
		"exclusively by the Collector"
	], 0, "കേന്ദ്ര വിഷയം സംസ്ഥാനം ഏജന്റായി നടത്തുന്നു. ഉദാ: വിദേശികളുടെ രജിസ്ട്രേഷൻ, ചില Central Acts. App 8. 1976-77 മുതൽ ചില ലബ്ധികൾ State section-ൽ.", "Union subject administered by the State on an agency basis. Appendix 8.", ["agency"]),
	Q("c2-17", "ch2", "11", "medium", "The term 'Estimating Officer' includes, for specified heads —", [
		"only the Finance Minister",
		"the Accountant General",
		"the Speaker",
		"the Governor's Secretary only"
	], 1, "ചില ഹെഡുകൾക്ക് AG തന്നെ Estimating Officer. App 6/9 നോക്കുക.", "Estimating Officer includes the Accountant General for specified heads.", ["estimating-officer"]),
	Q("c2-18", "ch2", "11", "easy", "A detailed head is the —", [
		"first tier of classification",
		"second tier of classification",
		"fifth tier of classification",
		"name of a grant"
	], 2, "Detailed head = അഞ്ചാം തട്ട് = object classification.", "Fifth tier of classification.", ["detailed-head"]),
	Q("c2-19", "ch2", "11", "easy", "A major head is the —", [
		"first tier",
		"second tier",
		"fourth tier",
		"unit of appropriation from 1974-75"
	], 1, "Major head = രണ്ടാം തട്ട് = function.", "Second tier of classification (function).", ["major-head"]),
	Q("c2-20", "ch2", "11", "medium", "Sector, in the five-tier system, represents —", [
		"the object of expenditure",
		"broad groupings of functions or services of Government",
		"a scheme under a programme",
		"a demand for grant"
	], 1, "Sector = വിശാല ഫംഗ്ഷൻ ഗ്രൂപ്പ്. ഒന്നാം തട്ട്.", "Broad groupings of functions or services.", ["sector"]),
	Q("c2-21", "ch2", "11", "hard", "Which of the following is NOT a correct pairing?", [
		"Reappropriation — transfer within a grant",
		"Surrender — offering savings to FD through Admin Dept",
		"Resumption — FD taking surrendered savings to Government account",
		"New Service — expenditure already fully provided in the AFS"
	], 3, "New Service = AFS-ൽ കാണാത്തത്. നൽകിയ ഓപ്ഷൻ തെറ്റാണ്.", "New Service is NOT something already fully contemplated in the AFS.", ["definitions"]),
	Q("c2-22", "ch2", "11", "medium", "Charged expenditure can be —", [
		"voted but not discussed",
		"discussed but not submitted to the vote of the Legislature",
		"neither discussed nor mentioned in the AFS",
		"reappropriated freely to voted heads"
	], 1, "Charged: നിയമസഭ ചർച്ച ചെയ്യാം, വോട്ട് ചെയ്യരുത്. Voted ↔ Charged reappropriation നിരോധിതം.", "Charged expenditure may be discussed but is not voted.", ["charged"]),
	Q("c2-23", "ch2", "11", "easy", "The financial year of the State is —", [
		"1 January to 31 December",
		"1 April to 31 March",
		"1 July to 30 June",
		"1 October to 30 September"
	], 1, "സാമ്പത്തിക വർഷം ഏപ്രിൽ 1 മുതൽ മാർച്ച് 31 വരെ. (AFS ഈ വർഷത്തേക്ക്).", "1 April to 31 March.", ["year"]),
	Q("c2-24", "ch2", "11", "medium", "Token grant / token sum of Rs 100 is typically used when —", [
		"the entire cost must come from Contingency Fund as a token",
		"savings exist to meet a New Service but Legislature's vote is still needed to bring the item within the scope of the grant",
		"the Appropriation Act is not published",
		"charged expenditure is to be converted to voted"
	], 1, "മിച്ചം കൊണ്ട് പുതിയ സേവനം നടത്താമെങ്കിലും, ഗ്രാന്റിന്റെ പരിധിക്ക് പുറത്താകയാൽ Rs 100 token supplementary വേണം. Contingency Fund advance ഒരിക്കലും token അല്ല — മുഴുവൻ തുക.", "Token Rs 100 when savings can meet a New Service but a vote is still required.", ["token"])
];
var ch3 = [
	Q("c3-01", "ch3", "12-14", "easy", "Estimates of Government are prepared on —", [
		"accrual basis including assets and liabilities",
		"cash basis — money expected to be received or paid during the year",
		"commitment basis only",
		"double-entry commercial basis for all departments"
	], 1, "കാഷ് ബേസിസ്: ആ വർഷം പണമായി കിട്ടാനോ അടയ്ക്കാനോ സാധ്യതയുള്ളത് മാത്രം. ആസ്തി-ബാധ്യത ബജറ്റ് എസ്റ്റിമേറ്റിൽ ഇല്ല (Explanatory Memorandum-ൽ പ്രത്യേകം).", "Close estimating on a cash basis; no assets/liabilities in the estimates themselves.", ["cash-basis"]),
	Q("c3-02", "ch3", "14", "medium", "Lump-sum provisions in the estimates should be —", [
		"used freely for flexibility",
		"avoided as far as possible, except grants to local bodies and similar cases",
		"the normal form of a Demand",
		"allowed only for salaries"
	], 1, "ലമ്പ് സം ഒഴിവാക്കുക. ഒഴിവ്: തദ്ദേശ സ്ഥാപനങ്ങൾക്കുള്ള ഗ്രാന്റ് പോലുള്ളവ. നിയന്ത്രണം detailed head വഴി വേണം.", "Avoid lump sums except grants to local bodies etc.", ["lump-sum"]),
	Q("c3-03", "ch3", "15-16", "easy", "Part I of the estimates relates to —", [
		"all new schemes",
		"standing sanctions — existing establishment and continuing expenditure",
		"only Plan schemes",
		"only charged expenditure"
	], 1, "Part I = നിലവിലെ sanction-ുകൾ (നിലവിലുള്ള സ്ഥാപനം/തുടരുന്ന ചെലവ്). Part II = പുതിയ ചെലവ് / റവന്യൂ ഉപേക്ഷ.", "Part I: standing sanctions. Part II: new expenditure / abandonment of revenue.", ["part-i"]),
	Q("c3-04", "ch3", "15-16", "easy", "Part II schemes relate to —", [
		"only salaries of permanent staff",
		"new expenditure or abandonment of existing sources of revenue",
		"Public Account transactions",
		"reappropriation orders"
	], 1, "പുതിയ ചെലവ് അല്ലെങ്കിൽ നിലവിലെ വരുമാനം ഉപേക്ഷിക്കൽ = Part II. Non-plan-ന് Part II തുടരുന്നു. Plan: consolidated estimate.", "Part II: new expenditure or abandonment of revenue.", ["part-ii"]),
	Q("c3-05", "ch3", "16", "medium", "For Plan schemes, the Manual provides for —", [
		"Part II treatment of every continuing scheme each year",
		"a single consolidated estimate (existing + new) within the annual Plan outlay",
		"no estimate at all",
		"estimate only after PAC approval"
	], 1, "പ്ലാൻ സ്കീമുകൾ: നിലവിലുള്ളതും പുതിയതും ഒരു consolidated estimate, വാർഷിക പ്ലാൻ outlay-യ്ക്കുള്ളിൽ. Non-plan പുതിയത് Part II.", "Plan: one consolidated estimate within annual Plan outlay.", ["plan"]),
	Q("c3-06", "ch3", "19-21", "easy", "The best guide for framing next year's Budget Estimate is generally —", [
		"the original Budget Estimate of the current year",
		"the Revised Estimate of the current year",
		"the Appropriation Accounts of five years ago",
		"the Vote on Account"
	], 1, "RE അടുത്ത BE-യ്ക്ക് ഏറ്റവും നല്ല ഗൈഡ്. പക്ഷേ RE അധിക ചെലവിന് നിയമാധികാരമല്ല.", "Revised Estimate is the best guide for the next BE.", ["re"]),
	Q("c3-07", "ch3", "19", "medium", "The Revised Estimate —", [
		"authorises expenditure beyond the grant",
		"reduces the grant automatically if savings are seen",
		"does not by itself authorise extra expenditure or reduce the grant",
		"replaces the Appropriation Act"
	], 2, "RE ഒരു പ്രവചനം മാത്രം. കൂടുതൽ ചെലവ് = supplementary/reappropriation. മിച്ചം = surrender.", "RE neither authorises extra spend nor reduces the grant.", ["re"]),
	Q("c3-08", "ch3", "20", "medium", "Revised Estimates are generally framed using actuals of the first —", [
		"three months",
		"five months",
		"six months",
		"nine months"
	], 1, "ആദ്യ 5 മാസത്തെ actuals. രീതി: (i) 5 മാസം + ബാക്കി 7-ന്റെ എസ്റ്റിമേറ്റ് (ii) ആദ്യ 5 മാസത്തിന്റെ 12/5 മടങ്ങ് (iii) അനുപാത രീതി.", "RE uses actuals of the first five months.", ["re"]),
	Q("c3-09", "ch3", "20", "hard", "One recognised method of framing the Revised Estimate is to take —", [
		"twice the first three months",
		"12/5 times the actuals of the first five months",
		"10 times April actuals",
		"only the last year's BE"
	], 1, "12 മാസം / 5 മാസം = 12/5 × ആദ്യ അഞ്ച് മാസത്തെ actuals. മറ്റൊന്ന് 5+7. റൗണ്ട് ചെയ്യുക nearest hundred.", "12/5 times the actuals of the first five months is a standard method.", ["re"]),
	Q("c3-10", "ch3", "21", "easy", "Estimates should be rounded to the nearest —", [
		"rupee",
		"ten rupees",
		"hundred rupees",
		"thousand rupees"
	], 2, "ഓരോ detailed-head എസ്റ്റിമേറ്റും nearest hundred-ലേക്ക് റൗണ്ട് ചെയ്യുക.", "Round to the nearest hundred rupees.", ["rounding"]),
	Q("c3-11", "ch3", "23", "medium", "Losses should ordinarily —", [
		"be fully provided in the original estimates as a matter of course",
		"not be provided, except under special sanction of Finance Department",
		"be charged automatically",
		"be taken to Public Account"
	], 1, "നഷ്ടം സാധാരണ ബജറ്റിൽ ഇടരുത്. FD പ്രത്യേക അനുമതിയോടെ മാത്രം.", "Losses not ordinarily provided except with FD special sanction.", ["losses"]),
	Q("c3-12", "ch3", "24", "easy", "Revenue estimates should be framed on the basis of —", [
		"proposed new taxes not yet law",
		"existing rates of taxes, duties etc.",
		"the previous Collector's personal guess only",
		"Plan outlay"
	], 1, "നിലവിലെ നിരക്കിൽ വരുമാനം കണക്കാക്കുക. പുതിയ നികുതി നിയമമാകും മുമ്പ് എസ്റ്റിമേറ്റിൽ ഇടരുത്.", "On existing rates of taxes and duties.", ["revenue"]),
	Q("c3-13", "ch3", "25", "medium", "Provision should be made only for —", [
		"every scheme an officer hopes to start",
		"schemes which have been sanctioned",
		"schemes rejected by FD",
		"unsanctioned Part II items already spent"
	], 1, "അനുവദിച്ച സ്കീമുകൾക്ക് മാത്രം വകയിരുത്തുക. അനുവാദമില്ലാത്തത് Part II / പുതിയ sanction.", "Only sanctioned schemes.", ["sanction"]),
	Q("c3-14", "ch3", "27", "medium", "Subsequent modifications of estimates should reach Finance Department by the end of —", [
		"October",
		"November",
		"December",
		"January"
	], 2, "തുടർന്നുള്ള മാറ്റങ്ങൾ ഡിസംബർ അവസാനത്തോടെ FD-യിൽ. അന്തിമ Part I + തിരഞ്ഞെടുത്ത Part II ഏകദേശം ജനുവരി അവസാനം.", "Subsequent modifications by end of December.", ["dates"]),
	Q("c3-15", "ch3", "28", "medium", "No commitment should be made on a new scheme until —", [
		"the budget circular is issued",
		"the Appropriation Act is published in the Gazette and formal sanction is issued",
		"the RE is approved",
		"PAC meets"
	], 1, "പുതിയ സ്കീമിൽ കമ്മിറ്റ്‌മെന്റ്: Appropriation Act ഗസറ്റിൽ + ഔപചാരിക sanction. ബജറ്റിൽ കണ്ടു എന്നതുകൊണ്ട് മാത്രം ചെലവഴിക്കരുത്.", "Wait for Gazette publication of the Appropriation Act and formal sanction.", ["new-scheme"]),
	Q("c3-16", "ch3", "29 A(3)", "hard", "Pay and fixed allowances of officers for a month become due only after the end of the month. Therefore provision for March pay is made in —", [
		"the same year's estimates, because service is in March",
		"the following year's estimates, on cash basis",
		"the Contingency Fund",
		"neither year"
	], 1, "മാർച്ച് ശമ്പളം ഏപ്രിലിലാണ് കാഷായി കൊടുക്കുക. അതുകൊണ്ട് അടുത്ത വർഷത്തെ എസ്റ്റിമേറ്റിൽ. Department test-ലെ ക്ലാസിക് ചോദ്യം.", "March pay is provided in the following year's estimates (cash basis).", ["march-pay"]),
	Q("c3-17", "ch3", "31", "easy", "Part II proposals of departments should reach the Administrative Department by —", [
		"15th September",
		"1st October",
		"1st November",
		"30th November"
	], 1, "Part II: Admin-ലേക്ക് ഒക്ടോബർ 1; FD-യിലേക്ക് നവംബർ 1. അടിയന്തിര ക്രമത്തിൽ consolidated list.", "Part II to Admin Dept by 1 October; to FD by 1 November.", ["part-ii", "dates"]),
	Q("c3-18", "ch3", "31", "easy", "Part II proposals should reach Finance Department by —", [
		"15th September",
		"1st October",
		"1st November",
		"30th November"
	], 2, "FD-യ്ക്ക് നവംബർ 1. Plan/Revenue estimates നവംബർ 30. verwarring ഒഴിവാക്കുക.", "Part II to FD by 1 November.", ["part-ii", "dates"]),
	Q("c3-19", "ch3", "17", "hard", "Which of the following is generally NOT required to be treated as Part II?", [
		"A new work costing more than Rs 10,000",
		"Continuance of existing temporary posts",
		"Opening of a new school",
		"A large-scale purchase of new machinery"
	], 1, "താൽക്കാലിക തസ്തിക തുടരൽ Part I ആകാം. പുതിയ യന്ത്രം/വലിയ സ്കെയിൽ furniture, പുതിയ വർക്ക് > 10,000, recurring GIA വിപുലീകരണം = Part II. ഒഴിവുകൾ: non-gazetted additions ≤ Rs 2,500 p.a. തുടങ്ങിയവ.", "Continuance of temporary posts is typically not Part II.", ["part-ii"]),
	Q("c3-20", "ch3", "17", "hard", "A new work is ordinarily treated as Part II if it costs more than —", [
		"Rs 2,500",
		"Rs 10,000",
		"Rs 1 lakh",
		"Rs 5 lakh"
	], 1, "പുതിയ വർക്ക് > Rs 10,000 = Part II. Major work definition (>1 lakh) വേറെയാണ്.", "New works > Rs 10,000 go to Part II.", ["part-ii", "works"]),
	Q("c3-21", "ch3", "17", "medium", "Renewal or replacement of machinery, plant or furniture is generally —", [
		"Part II",
		"Part I",
		"always a New Service irrespective of cost",
		"charged expenditure"
	], 1, "പുതിയ വാങ്ങൽ വലിയ സ്കെയിൽ = Part II. പുതുക്കൽ/പകരം വയ്ക്കൽ = Part I.", "Renewal/replacement = Part I; new large-scale purchase = Part II.", ["part-i"]),
	Q("c3-22", "ch3", "18", "medium", "A Part II scheme not introduced (no commitment) during the year is —", [
		"automatically Part I next year",
		"treated as Part II again next year",
		"charged on the Fund",
		"dropped forever"
	], 1, "കമ്മിറ്റ്‌മെന്റ് ഇല്ലാത്ത Part II അടുത്ത വർഷവും Part II. ഓർഡർ/കോൺട്രാക്റ്റ് = introduced.", "If not introduced, it remains Part II next year.", ["part-ii"]),
	Q("c3-23", "ch3", "29 F", "medium", "The system of gross vote means, in substance, that —", [
		"recoveries are deducted before the vote",
		"the Legislature votes the gross amount, recoveries being shown separately and not reducing the vote",
		"only net surplus is voted",
		"charged items are voted gross"
	], 1, "Gross vote: വോട്ട് മൊത്തം തുകയ്ക്ക്. റിക്കവറി കിഴിച്ച് net വോട്ട് അല്ല. സ്റ്റോർസ്/Suspense-ന് App 5, Circular 72/76/Fin.", "Vote is on the gross amount; recoveries are not deducted from the vote.", ["gross-vote"]),
	Q("c3-24", "ch3", "12", "easy", "The estimating season is described as —", [
		"open estimating — include every wish-list item",
		"close estimating — as accurate as possible",
		"average of ten years only",
		"fixed by the Governor each week"
	], 1, "Close estimating: കഴിയുന്നത്ര കൃത്യം. അമിതമായി കൂട്ടുകയോ കുറയ്ക്കുകയോ അരുത്.", "Close estimating: accurate, neither padded nor under-provided.", ["estimating"]),
	Q("c3-25", "ch3", "26", "medium", "Inter-departmental adjustments should be provided for in —", [
		"supplementary estimates as a rule",
		"the original estimates",
		"the Public Account only",
		"excess grants"
	], 1, "വകുപ്പുകൾക്കിടയിലെ ക്രമീകരണം ആദ്യ എസ്റ്റിമേറ്റിൽ തന്നെ. സപ്ലിമെന്ററിയിൽ ഇടാറില്ല.", "Provide inter-departmental adjustments in the original estimate.", ["adjustments"]),
	Q("c3-26", "ch3", "22", "medium", "Average of the last three years is used particularly when —", [
		"framing all salary estimates",
		"receipts or fluctuating charges cannot be estimated more scientifically",
		"voting the Appropriation Bill",
		"issuing a letter of credit"
	], 1, "ചാഞ്ചാടുന്ന വരവ്/ചെലവ്: കഴിഞ്ഞ 3 വർഷത്തെ ശരാശരി ഒരു ഉപാധി. അന്ധമായി എല്ലാറ്റിനും അല്ല.", "Three-year average for fluctuating items when no better method exists.", ["average"]),
	Q("c3-27", "ch3", "17", "hard", "Non-gazetted additions to establishment costing not more than Rs 2,500 per annum are —", [
		"always Part II",
		"generally an exception from Part II",
		"charged on the Consolidated Fund",
		"New Service irrespective of cost"
	], 1, "Rs 2,500 p.a. വരെയുള്ള non-gazetted additions Part II ഒഴിവിൽ. പരീക്ഷയിൽ monetary limit ഓർക്കുക.", "Non-gazetted additions ≤ Rs 2,500 p.a. generally not Part II.", ["part-ii"]),
	Q("c3-28", "ch3", "30", "medium", "Committed (non-plan) expenditure and continuing developmental expenditure should be —", [
		"mixed without distinction",
		"clearly distinguished in the estimates",
		"both treated as charged",
		"shown only in performance budgets"
	], 1, "Committed non-plan vs continuing developmental — വേർതിരിച്ച് കാണിക്കുക. പ്ലാൻ/നോൺ-പ്ലാൻ നിയന്ത്രണത്തിന്.", "Distinguish committed non-plan from continuing developmental outlay.", ["plan"])
];
var ch4 = [
	Q("c4-01", "ch4", "32-33", "easy", "Number statements in Forms KBM 1 to 7 are appended as —", [
		"Appendix II to Demands for Grants",
		"Appendix I to the Detailed Budget Estimates",
		"Appendix 17 of the Constitution",
		"the Appropriation Act schedule"
	], 1, "KBM 1–7 നമ്പർ സ്റ്റേറ്റ്‌മെന്റുകൾ Detailed BE-യുടെ Appendix I ആയി. സ്റ്റാഫ് ശക്തി, DA, HRA, posts created/abolished തുടങ്ങിയവ.", "KBM 1–7 form Appendix I to the Detailed Budget Estimates.", ["kbm-forms"]),
	Q("c4-02", "ch4", "KBM 1", "easy", "Form KBM 1 shows —", [
		"guarantees outstanding",
		"number of Government officers on different scales of pay",
		"reappropriation sanctions",
		"letter of credit balances"
	], 1, "KBM 1: വിവിധ pay scale-ുകളിലെ ഉദ്യോഗസ്ഥ എണ്ണം.", "KBM 1: officers on different scales of pay.", ["forms"]),
	Q("c4-03", "ch4", "KBM 2", "easy", "Form KBM 2 relates to —", [
		"House Rent Allowance",
		"Dearness Allowance",
		"contingent establishment",
		"works appendix"
	], 1, "KBM 2 = വിവിധ DA നിരക്കുകൾ. KBM 3 = HRA.", "KBM 2: different rates of Dearness Allowance.", ["forms"]),
	Q("c4-04", "ch4", "KBM 3", "easy", "Form KBM 3 relates to —", [
		"Dearness Allowance",
		"House Rent Allowance",
		"fixed allowances",
		"posts created or abolished"
	], 1, "KBM 3: HRA നിരക്കുകൾ.", "KBM 3: different rates of House Rent Allowance.", ["forms"]),
	Q("c4-05", "ch4", "KBM 4", "easy", "Form KBM 4 is for —", [
		"contingent establishment",
		"statement of guarantees",
		"liability register",
		"warning slips"
	], 0, "KBM 4 = Contingent Establishment.", "KBM 4: Contingent Establishment.", ["forms"]),
	Q("c4-06", "ch4", "KBM 5", "easy", "Form KBM 5 is the statement of —", [
		"fixed allowances",
		"sanctioned posts in each permanent and temporary establishment (gazetted and non-gazetted)",
		"properties leased at concessional rent",
		"draft audit paragraphs"
	], 1, "KBM 5: അനുവദിച്ച തസ്തികകൾ — permanent/temporary, gazetted/non-gazetted.", "KBM 5: sanctioned posts in each establishment.", ["forms"]),
	Q("c4-07", "ch4", "KBM 6", "easy", "Form KBM 6 is the statement of —", [
		"fixed allowances",
		"posts created/abolished",
		"guarantees",
		"motor vehicles"
	], 0, "KBM 6 = fixed allowances.", "KBM 6: statement of fixed allowances.", ["forms"]),
	Q("c4-08", "ch4", "KBM 7", "easy", "Form KBM 7 shows details of —", [
		"posts created/abolished",
		"contingent establishment",
		"number statements of DA",
		"irrigation capital outlay only"
	], 0, "KBM 7: സൃഷ്ടിച്ച/നിർത്തലാക്കിയ തസ്തികകൾ.", "KBM 7: posts created or abolished.", ["forms"]),
	Q("c4-09", "ch4", "KBM 8", "medium", "Form KBM 8 lists cases/schemes where expenditure is expected to exceed appreciably —", [
		"the letter of credit",
		"the amount originally intimated to the Legislature",
		"the Contingency Fund corpus",
		"the PAC ceiling"
	], 1, "നിയമസഭയോട് ആദ്യം പറഞ്ഞ തുകയെക്കാൾ ഗണ്യമായി കവിയുമെന്ന് കരുതുന്ന സ്കീമുകൾ — New Service അല്ലെങ്കിൽ കുറിപ്പ് Budget Memorandum-ൽ.", "Schemes expected to exceed the amount originally intimated to the Legislature.", ["forms"]),
	Q("c4-10", "ch4", "KBM 10", "medium", "Form KBM 10 is the statement of —", [
		"liabilities of disbursing officers",
		"guarantees given by the Government of Kerala outstanding on a date",
		"reappropriation",
		"draft paragraphs"
	], 1, "KBM 10: സർക്കാർ ഗ്യാരണ്ടികൾ — ബാക്കി തുക.", "Outstanding guarantees of the Government of Kerala.", ["forms", "guarantees"]),
	Q("c4-11", "ch4", "35-40", "medium", "Appendix of works attached to the budget shows —", [
		"only maintenance of staff cars",
		"details of works for which provision is made",
		"PAC minutes",
		"treasury balances"
	], 1, "Works Appendix: ബജറ്റിലെ വർക്കുകളുടെ വിവരം. Appendix-ൽ ഇല്ലാത്ത വർക്കിന് ഫണ്ട് മാറ്റരുത് (പിന്നീടുള്ള നിരോധനം).", "Works appendix lists works for which provision is made.", ["works"]),
	Q("c4-12", "ch4", "App 6", "medium", "The list of Estimating Officers for receipt, debt, deposit and remittance heads is in —", [
		"Appendix 3",
		"Appendix 6",
		"Appendix 11",
		"Appendix 16"
	], 1, "App 6 = Estimating Officers (receipts, debt, deposit, remittance). App 9 = CCO/SCO (expenditure).", "Appendix 6: Estimating Officers for those heads.", ["appendix-6"]),
	Q("c4-13", "ch4", "App 9", "easy", "Chief Controlling Officers and Subordinate Controlling Officers are listed in —", [
		"Appendix 4",
		"Appendix 8",
		"Appendix 9",
		"Appendix 14"
	], 2, "App 9 വലിയ പട്ടിക: CCO, SCO, Estimating Officers (expenditure). Column 4 പലപ്പോൾ reappropriation അധികാരം.", "Appendix 9 lists CCOs and SCOs.", ["cco"]),
	Q("c4-14", "ch4", "41-46", "medium", "Estimates of debt heads, deposits and remittances are generally framed by —", [
		"every village officer",
		"the officers specified in the list of Estimating Officers, often including AG for some heads",
		"PAC",
		"the Speaker"
	], 1, "Debt/deposit/remittance: നിശ്ചിത Estimating Officers; ചിലത് AG.", "Specified Estimating Officers; AG for some heads.", ["debt"]),
	Q("c4-15", "ch4", "36", "medium", "Proposals for new expenditure under Part II should indicate —", [
		"only the current year's cost",
		"ultimate cost as well as cost in the budget year, recurring and non-recurring",
		"only non-recurring cost",
		"no cost if Plan-funded"
	], 1, "Part II: ആ വർഷത്തെ ചെലവ് + ആത്യന്തിക ചെലവ്, recurring/non-recurring വേർതിരിച്ച്.", "Show budget-year and ultimate cost, recurring and non-recurring.", ["part-ii"]),
	Q("c4-16", "ch4", "KBM 9", "medium", "Form KBM 9 gives particulars of —", [
		"properties or assets proposed to be transferred free of cost or sold at concessional rates",
		"warning slips",
		"letters of credit",
		"charged items under Art. 202"
	], 0, "സൗജന്യ/ഇളവ് നിരക്കിൽ ആസ്തി കൈമാറ്റം — നിയമസഭയറിയണം.", "Assets transferred free or at concessional rates.", ["forms"]),
	Q("c4-17", "ch4", "KBM 11", "medium", "Form KBM 11 relates to Government properties —", [
		"sold in auction only",
		"leased out at subsidised or concessional rates of rent where standard rent has not been fixed",
		"acquired under land acquisition only",
		"held in the Public Account"
	], 1, "സബ്സിഡി/ഇളവ് വാടകയ്ക്ക് ലീസ്; standard rent ഇല്ലാത്തവ.", "Properties leased at concessional rent without standard rent.", ["forms"])
];
var ch5 = [
	Q("c5-01", "ch5", "51", "easy", "Which of the following is a principal budget document presented to the Legislature?", [
		"The Draft Audit Paragraph",
		"The Annual Financial Statement",
		"The Letter of Credit",
		"The Warning Slip"
	], 1, "പ്രധാന രേഖകൾ: AFS, Detailed Revenue, Demands for Grants + Detailed BE, Explanatory Memorandum, Staff/Works appendices, Debt heads, Five Year Plan programme, Performance Budgets, Evaluation Reports.", "The Annual Financial Statement is the principal budget document (Art. 202).", ["documents"]),
	Q("c5-02", "ch5", "51", "medium", "The statement of assets and liabilities of the Government is appended to —", [
		"the Appropriation Act",
		"the Explanatory Memorandum",
		"the Vote on Account",
		"Appendix 13"
	], 1, "ആസ്തി-ബാധ്യത Explanatory Memorandum-നോട് അനുബന്ധം. ബജറ്റ് എസ്റ്റിമേറ്റ് കാഷ് ബേസിസ് ആയതുകൊണ്ട് ഇത് പ്രത്യേകം.", "Assets and liabilities are appended to the Explanatory Memorandum.", ["memorandum"]),
	Q("c5-03", "ch5", "51", "medium", "Demands for Grants are presented along with —", [
		"only the Finance Accounts",
		"Detailed Budget Estimates",
		"PAC reports of the previous ten years",
		"the Contingency Fund Act"
	], 1, "Demands for Grants + Detailed BE ഒരുമിച്ച്. ഓരോ Demand-ും ഒരു സേവനത്തിന്.", "Demands for Grants with Detailed Budget Estimates.", ["documents"]),
	Q("c5-04", "ch5", "52", "medium", "An 'Agency subject' example listed in the Manual is —", [
		"collection of State land revenue",
		"registration and surveillance of foreigners",
		"High Court administration",
		"State lottery"
	], 1, "ഏജൻസി: foreigners registration/surveillance, deportation, Indo-Pak/Bangladesh passport, Political Pensions (Malikhana), ചില Central Acts (Explosives, Petroleum, Arms, Rice milling). App 8.", "Foreigners' registration/surveillance is a classic agency subject. Appendix 8.", ["agency"]),
	Q("c5-05", "ch5", "52", "hard", "From 1976-77, receipts relating to certain Central Acts administered as agency subjects are —", [
		"credited in the State section of accounts",
		"always remitted in cash to Delhi the same day",
		"taken to Contingency Fund",
		"ignored in estimates"
	], 0, "1976-77 മുതൽ ഈ Central Acts-ന്റെ ലബ്ധി State section-ൽ ക്രെഡിറ്റ്. പരീക്ഷയിൽ വർഷം ചോദിക്കാറുണ്ട്.", "From 1976-77 those receipts are credited in the State section.", ["agency"]),
	Q("c5-06", "ch5", "52", "hard", "Political Pensions from Central Revenues (Malikhana) referred to in the Manual include about 95 allowances amounting, from 1961-62, to —", [
		"Rs 200 per annum",
		"Rs 2,000 per annum",
		"Rs 2 lakh per annum",
		"Rs 20 lakh per annum"
	], 1, "Malikhana: ഏകദേശം 95 allowances, 1961-62 മുതൽ Rs 2,000 a year — ഏജൻസി വിഷയം.", "About Rs 2,000 per annum from 1961-62.", ["agency"]),
	Q("c5-07", "ch5", "53", "easy", "Performance budgeting was recommended by the Administrative Reforms Commission in —", [
		"January 1966",
		"January 1968",
		"April 1974",
		"November 1968"
	], 1, "ARC, ജനുവരി 1968: development programmes നേരിട്ട് കൈകാര്യം ചെയ്യുന്ന വകുപ്പുകളിൽ performance budget.", "ARC recommended performance budgeting in January 1968.", ["performance"]),
	Q("c5-08", "ch5", "53", "easy", "Kerala's first Performance Budget (1970-71) was for —", [
		"Education Department",
		"Public Works Department (Buildings and Roads)",
		"Forest Department",
		"Finance Department"
	], 1, "ആദ്യം PWD (B&R) 1970-71. പിന്നീട് തിരഞ്ഞെടുത്ത വകുപ്പുകൾ.", "PWD (B&R) in 1970-71.", ["performance"]),
	Q("c5-09", "ch5", "53", "medium", "A Performance Budget has three parts. Part II deals with —", [
		"Introduction only",
		"Financial Requirements (programme, object-wise, sources — totals equal)",
		"Evaluation reports of CAG",
		"Vote on Account"
	], 1, "Part I Intro; Part II Financial Requirements (programme/object/sources — ആകെ തുല്യം); Part III Explanation of Financial Requirements.", "Part II: Financial Requirements; the three statements' totals must agree.", ["performance"]),
	Q("c5-10", "ch5", "53", "medium", "Evaluation reports accompanying performance budgets are meant for —", [
		"the Cabinet only",
		"the Legislature",
		"the CAG exclusively",
		"the Governor's household"
	], 1, "Evaluation reports നിയമസഭയിലേക്ക് — പണം കൊണ്ട് എന്ത് നേടി എന്ന്.", "Evaluation reports are presented to the Legislature.", ["performance"]),
	Q("c5-11", "ch5", "47-50", "medium", "The day of presentation of the budget is fixed by —", [
		"the Finance Minister",
		"the Governor",
		"the Speaker",
		"the Chief Minister"
	], 1, "അവതരണ ദിവസം ഗവർണർ നിശ്ചയിക്കുന്നു. സാധാരണ ഫെബ്രുവരി അവസാനം / മാർച്ച് ആദ്യം. അന്ന് ചർച്ചയില്ല.", "The Governor fixes the day of presentation.", ["presentation"]),
	Q("c5-12", "ch5", "51", "medium", "Appendix I to the budget documents typically relates to —", [
		"staff",
		"public undertakings list",
		"new service rulings",
		"Contingency Fund rules"
	], 0, "App I Staff, App II Works — ബജറ്റ് രേഖകളോട്. Manual-ന്റെ App 1 അക്കൗണ്ട് ഡിവിഷനുകളാണ്; verwarring ഒഴിവാക്കുക.", "Staff details as Appendix I to the budget documents.", ["documents"]),
	Q("c5-13", "ch5", "App 8", "easy", "Union (Agency) Subjects are listed in —", [
		"Appendix 4",
		"Appendix 8",
		"Appendix 13",
		"Appendix 16"
	], 1, "App 8 = Agency subjects.", "Appendix 8.", ["agency"]),
	Q("c5-14", "ch5", "53", "hard", "In the Performance Budget, totals of the programme classification, object-wise classification and sources of finance should —", [
		"each be independently voted",
		"be equal",
		"exclude charged items always",
		"be shown only in Malayalam"
	], 1, "മൂന്ന് കോണിലെയും ആകെ തുല്യമായിരിക്കണം — സമഗ്രതയുടെ പരിശോധന.", "The three statements must total the same.", ["performance"])
];
var ch6 = [
	Q("c6-01", "ch6", "54", "easy", "There is no discussion of the budget on —", [
		"the day of voting of demands",
		"the day of presentation",
		"the day the Appropriation Bill is passed",
		"the last day of March"
	], 1, "അവതരണ ദിവസം ചർച്ചയില്ല. ശേഷം general discussion, പിന്നെ demands-ന്റെ voting.", "No discussion on the day of presentation.", ["presentation"]),
	Q("c6-02", "ch6", "54-55", "easy", "After general discussion of the budget, the Finance Minister —", [
		"must dissolve the House",
		"may choose to reply",
		"cannot speak again",
		"presents the Appropriation Accounts"
	], 1, "General discussion-ന് ശേഷം FM-ന് മറുപടി പറയാം (right of reply).", "The FM has a right of reply at the end of general discussion.", ["discussion"]),
	Q("c6-03", "ch6", "55", "easy", "A Demand for Grant can be made only on the recommendation of —", [
		"the Speaker",
		"the Governor",
		"the Accountant General",
		"the PAC"
	], 1, "ഗവർണറുടെ ശുപാർശയില്ലാതെ Demand ഇടരുത്. ഭരണഘടനാ നിയന്ത്രണം.", "Demand for Grant only on the Governor's recommendation.", ["demand"]),
	Q("c6-04", "ch6", "56", "medium", "If the House reduces a demand, the reduction is distributed among sub-heads by —", [
		"the Speaker",
		"the Finance Department",
		"the concerned Disbursing Officer",
		"the CAG"
	], 1, "Demand കുറച്ചാൽ FD sub-heads-നിടയിൽ verteilt ചെയ്യുന്നു. കുറച്ച യൂണിറ്റ് പിന്നീട് താഴേത്തട്ട് സ്വയം കൂട്ടരുത്.", "Finance Department distributes the reduction among sub-heads.", ["reduction"]),
	Q("c6-05", "ch6", "57", "easy", "The Appropriation Bill provides for appropriation of grants and of charged expenditure, not exceeding —", [
		"the Revised Estimate",
		"the amounts shown in the statement laid before the House",
		"last year's actuals",
		"the Contingency Fund"
	], 1, "AFS/statement-ൽ കാണിച്ച തുകയിൽ കവിയരുത്. Grants + charged ഒരുമിച്ച് Bill-ൽ.", "Not exceeding the amounts in the statement laid before the House.", ["appropriation-bill"]),
	Q("c6-06", "ch6", "57", "medium", "The schedule to the Appropriation Act separates —", [
		"Plan and Non-plan only",
		"revenue and capital (reappropriation between them is prohibited)",
		"voted expenditure of each officer",
		"agency and State subjects only"
	], 1, "Schedule: revenue vs capital വേർതിരിക്കുന്നു. ഇവയ്ക്കിടയിൽ reappropriation നിരോധിതം.", "Schedule separates revenue and capital; no reappropriation between them.", ["appropriation-act"]),
	Q("c6-07", "ch6", "57", "medium", "No amendment to the Appropriation Bill is admissible which —", [
		"is moved by a Minister",
		"varies the amount or destination of a grant",
		"is merely verbal",
		"seeks to discuss charged items"
	], 1, "തുകയോ ഉദ്ദേശ്യമോ മാറ്റുന്ന ഭേദഗതി പറ്റില്ല. Grant already voted ആണ് അടിസ്ഥാനം.", "No amendment varying amount or destination of a grant.", ["appropriation-bill"]),
	Q("c6-08", "ch6", "57", "easy", "After the Governor's assent, the Appropriation Act is —", [
		"kept confidential until PAC meets",
		"published in the Gazette",
		"sent only to the CAG",
		"appended to Appendix 13"
	], 1, "അസന്റ് ശേഷം ഗസറ്റ്. ഗസറ്റ് പ്രസിദ്ധീകരണം തന്നെ പേയ്‌മെന്റ് അധികാരം.", "Published in the Gazette after assent.", ["gazette"]),
	Q("c6-09", "ch6", "58", "easy", "Vote on Account is provided in —", [
		"Article 202",
		"Article 204",
		"Article 205",
		"Article 206(1)"
	], 3, "Art. 206(1): വർഷത്തിന്റെ ഒരു ഭാഗത്തേക്ക് advance. പുതിയ സേവനത്തിനല്ല; അംഗീകൃത സേവനങ്ങൾക്ക്. അവിശ്വാസം/പിരിച്ചുവിടൽ/തിരഞ്ഞെടുപ്പ് സമയത്തും.", "Vote on Account: Article 206(1) — advance for part of the year.", ["vote-on-account"]),
	Q("c6-10", "ch6", "58", "medium", "A Vote on Account is intended to cover —", [
		"new services not in the AFS",
		"expenditure on services already approved, for a part of the year",
		"excesses of past years",
		"charged debt only"
	], 1, "നിലവിൽ അംഗീകരിച്ച സേവനങ്ങൾക്ക് ഭാഗിക വർഷ advance. പുതിയ നയത്തിന് Vote on Account ഉപയോഗിക്കരുത്.", "Only services already approved, for part of the year.", ["vote-on-account"]),
	Q("c6-11", "ch6", "58", "hard", "Vote of Credit and Exceptional Grant are also provided in Article 206(1). In Kerala they have —", [
		"been used every year",
		"never been used so far (as stated in the Manual)",
		"replaced the Appropriation Act",
		"been used only for agency subjects"
	], 1, "Vote of Credit: അപ്രതീക്ഷിതം, വലിപ്പം നിശ്ചയിക്കാൻ ബുദ്ധിമുട്ട്. Exceptional Grant: നടപ്പ് സേവനത്തിന്റെ ഭാഗമല്ല. കേരളത്തിൽ ഇതുവരെ ഉപയോഗിച്ചിട്ടില്ല (Manual).", "Never used in Kerala so far, according to the Manual.", ["vote-of-credit"]),
	Q("c6-12", "ch6", "59", "easy", "When a New Service can be met from savings, the Legislature is asked to vote a token sum of —", [
		"Rs 1",
		"Rs 100",
		"Rs 1,000",
		"Rs 1 lakh"
	], 1, "Token Rs 100. കുറിപ്പിൽ പൂർണ്ണ implication. Contingency Fund advance മുഴുവൻ തുക — token അല്ല.", "Token sum of Rs 100.", ["token"]),
	Q("c6-13", "ch6", "59", "medium", "An advance from the Contingency Fund for a New Service is —", [
		"always a token of Rs 100",
		"the full amount required, never a token",
		"limited to Rs 2,500",
		"voted by PAC first"
	], 1, "അടിയന്തരം: Contingency Fund-ൽ നിന്ന് മുഴുവൻ തുക. പിന്നീട് supplementary വച്ച് ഫണ്ട് വീണ്ടും നിറയ്ക്കുക.", "Contingency Fund advance is the full amount, never token.", ["contingency-fund"]),
	Q("c6-14", "ch6", "55", "medium", "Charged expenditure included in the AFS is —", [
		"voted along with demands",
		"open to discussion but not to vote",
		"omitted from the Appropriation Bill",
		"met from Public Account"
	], 1, "Charged ചർച്ച ചെയ്യാം, വോട്ട് ചെയ്യരുത്. Appropriation Bill-ൽ charged ഉം ഉൾപ്പെടും — നിയമാധികാരത്തിന്.", "Discussed but not voted; still included in the Appropriation Act.", ["charged"]),
	Q("c6-15", "ch6", "App 7", "medium", "Procedure in financial matters in the Assembly is given in —", [
		"Appendix 4",
		"Appendix 7",
		"Appendix 11",
		"Appendix 15"
	], 1, "App 7: Procedure in financial matters (Assembly rules extract).", "Appendix 7.", ["procedure"]),
	Q("c6-16", "ch6", "54", "easy", "The budget is presented to the Legislature towards —", [
		"the end of February or beginning of March",
		"15th September",
		"30th November",
		"the first working day of April"
	], 0, "ഫെബ്രുവരി അവസാനം / മാർച്ച് ആദ്യം — ക്ലാസിക് ഉത്തരം.", "End of February or beginning of March.", ["dates"]),
	Q("c6-17", "ch6", "58", "hard", "A Vote on Account may also be taken when the Assembly is —", [
		"considering a privilege motion only",
		"dissolved or a general election is due, so that the new House can consider the full budget",
		"discussing a draft paragraph",
		"passing an excess grant"
	], 1, "പിരിച്ചുവിടൽ/തിരഞ്ഞെടുപ്പ്: പുതിയ സഭ പൂർണ്ണ ബജറ്റ് നോക്കും; അതുവരെ Vote on Account.", "Also used on dissolution/election so the new House can vote the full budget.", ["vote-on-account"])
];
var ch7 = [
	Q("c7-01", "ch7", "61", "easy", "Control of expenditure is exercised by —", [
		"the Legislature, the Executive and Audit",
		"the Finance Minister alone",
		"Disbursing Officers only",
		"the Governor's household"
	], 0, "മൂന്ന് തലം: നിയമസഭ (ഗ്രാന്റ്), എക്സിക്യൂട്ടീവ് (CCO ശ്രേണി), ഓഡിറ്റ് (AG/CAG).", "Legislature, Executive and Audit.", ["control"]),
	Q("c7-02", "ch7", "62", "medium", "A Chief Controlling Officer, while distributing funds, should ordinarily —", [
		"distribute the entire grant on 1 April without reserve",
		"retain a reserve to meet unforeseen needs",
		"surrender everything in April",
		"send all funds to PAC"
	], 1, "മുഴുവൻ തുക ആദ്യം verteilt ചെയ്യരുത്. ഒരു reserve CCO നിർത്തണം.", "CCO should retain a reserve.", ["cco"]),
	Q("c7-03", "ch7", "62", "medium", "For the 'Buildings' sub-head, the sole Chief Controlling Officer is —", [
		"every Collector",
		"the Chief Engineer (General, Buildings and Roads)",
		"the Finance Secretary",
		"the Accountant General"
	], 1, "ബിൽഡിങ്സ്: CE (General, B&R) മാത്രം CCO — വകുപ്പുകൾ തമ്മിൽ ചിതറാതിരിക്കാൻ.", "CE (General, B&R) is the sole CCO for Buildings.", ["buildings"]),
	Q("c7-04", "ch7", "63", "easy", "If there is no detailed head, the unit of appropriation is —", [
		"the sector",
		"the sub-head or minor head",
		"the entire Consolidated Fund",
		"the Vote on Account"
	], 1, "Detailed head ഉണ്ടെങ്കിൽ അതാണ് യൂണിറ്റ്; ഇല്ലെങ്കിൽ sub-head / minor head.", "Sub-head or minor head in the absence of a detailed head.", ["unit"]),
	Q("c7-05", "ch7", "65", "easy", "Warning Slips are issued by —", [
		"the Finance Minister",
		"the Accountant General to the CCO and Finance Department",
		"the PAC Chairman",
		"the Treasury Officer to the Governor"
	], 1, "AG Warning Slip: ചെലവ് ഗ്രാന്റിനെ സമീപിക്കുകയോ കവിയുകയോ ചെയ്യുമ്പോൾ. CCO + FD. നടപടി രേഖപ്പെടുത്തി തിരിച്ചയയ്ക്കുക.", "AG issues Warning Slips to CCO and FD.", ["warning-slip"]),
	Q("c7-06", "ch7", "App 11", "easy", "The system of Appropriation Control was introduced with effect from —", [
		"1 April 1966",
		"1 April 1974",
		"15 July 1980",
		"1 April 1977"
	], 1, "1 Apr 1974, 15 വകുപ്പുകൾ. G.O.(P) 49/74/Fin dated 1 Mar 1974. App 11.", "From 1 April 1974. G.O.(P) 49/74/Fin. Appendix 11.", ["appropriation-control"]),
	Q("c7-07", "ch7", "App 11", "medium", "Under Appropriation Control, bills are generally returned if appropriation is insufficient, except that the following are typically exempt —", [
		"office expenses and fuel",
		"salaries, wages and pensions",
		"major works",
		"grants-in-aid"
	], 1, "ശമ്പളം, വേതനം, പെൻഷൻ ഒഴിവ് — ജീവനക്കാരെ ബാധിക്കാതിരിക്കാൻ. മറ്റ് ബില്ലുകൾ appropriation ഇല്ലെങ്കിൽ തിരിച്ചയയ്ക്കും.", "Salaries, wages and pensions are exempt.", ["appropriation-control"]),
	Q("c7-08", "ch7", "App 12", "easy", "The system of Letter of Credit was introduced from 1 April 1974 in —", [
		"all civil departments",
		"PWD, Public Health Engineering and Forest",
		"Education and Health only",
		"the Secretariat only"
	], 1, "LoC: PWD, PHE, Forest — 1 Apr 1974. Harbour Engineering: 15 Jul 1980, G.O.(MS) 451/80/Fin. G.O.(P) 46/74/Fin 27 Feb 1974. App 12.", "PWD, PHE and Forest from 1 April 1974.", ["loc"]),
	Q("c7-09", "ch7", "App 12", "medium", "Harbour Engineering was brought under Letter of Credit from —", [
		"1 April 1974",
		"15 July 1980",
		"1 April 1982",
		"November 1968"
	], 1, "15 ജൂലൈ 1980. G.O.(MS) 451/80/Fin.", "15 July 1980.", ["loc"]),
	Q("c7-10", "ch7", "App 12", "medium", "A Letter of Credit is ordinarily issued for —", [
		"one month",
		"three months at a time",
		"the whole financial year in one instalment always",
		"ten years"
	], 1, "LoC 3 മാസത്തേക്ക്. ചെലവഴിക്കാത്തത് കൊണ്ടുപോകാം — മാർച്ച് ഒഴികെ (lapse).", "Three months at a time.", ["loc"]),
	Q("c7-11", "ch7", "App 12", "hard", "Unspent balance of a Letter of Credit —", [
		"never carries over",
		"carries over except in March, when it lapses",
		"is credited to Contingency Fund",
		"becomes charged expenditure"
	], 1, "മാർച്ചിലെ ബാക്കി lapse. മറ്റ് മാസങ്ങളിൽ carry over.", "Carries over except March (lapses).", ["loc"]),
	Q("c7-12", "ch7", "App 12", "hard", "Expenditure may exceed the monthly credit under LoC by up to —", [
		"5%",
		"10%",
		"20% of the monthly credit, if adjusted in the remaining months of the quarter",
		"50% without adjustment"
	], 2, "മാസ ക്രെഡിറ്റിന്റെ 20% വരെ കവിയാം; അതേ ക്വാർട്ടറിലെ ബാക്കി മാസങ്ങളിൽ ക്രമീകരിക്കണം.", "Up to 20% of monthly credit, adjusted within the quarter.", ["loc"]),
	Q("c7-13", "ch7", "App 12", "hard", "Which of the following is NOT exempt from Letter of Credit?", [
		"Salaries and wages",
		"Refund of EMD/security/retention deposits",
		"Work done for other divisions/departments/agencies",
		"Provident Fund, scholarships, stipends, LIC premia, HBA, National Highways"
	], 2, "മറ്റ് ഡിവിഷൻ/വകുപ്പ്/ഏജൻസിക്ക് വേണ്ടിയുള്ള വർക്ക് LoC-യ്ക്കുള്ളിൽ. ഒഴിവ്: ശമ്പളം/വേതനം, ഡിപ്പോസിറ്റ് റീഫണ്ട്, PF, സ്കോളർഷിപ്പ്, സ്റ്റൈപ്പന്റ്, LIC, HBA, NH.", "Work for other divisions/departments is WITHIN LoC, not exempt.", ["loc"]),
	Q("c7-14", "ch7", "KBM 12", "easy", "Form KBM 12 is the Disbursing Officer's register of —", [
		"reappropriation",
		"expenditure and liabilities for the month",
		"guarantees",
		"performance indicators"
	], 1, "KBM 12: DO-യുടെ മാസ ചെലവ് + ബാധ്യത.", "DO's monthly register of expenditure and liabilities.", ["forms"]),
	Q("c7-15", "ch7", "KBM 13", "easy", "Form KBM 13 is the —", [
		"Liability Register for the year",
		"Warning Slip",
		"Appropriation Bill",
		"Draft Paragraph"
	], 0, "KBM 13 = വാർഷിക Liability Register.", "Annual Liability Register.", ["forms"]),
	Q("c7-16", "ch7", "KBM 14", "easy", "Form KBM 14 is the —", [
		"monthly liability statement",
		"circle consolidation of PWD",
		"Forest works statement",
		"reappropriation application"
	], 0, "KBM 14: മാസത്തെ liability statement.", "Monthly liability statement.", ["forms"]),
	Q("c7-17", "ch7", "KBM 15", "easy", "Form KBM 15 is the consolidated register of expenditure and liabilities of —", [
		"the PAC",
		"the Subordinate or Chief Controlling Officer",
		"the Governor",
		"the Estimates Committee"
	], 1, "SCO/CCO ഏകീകരണ രജിസ്റ്റർ — KBM 15.", "SCO/CCO consolidated register.", ["forms"]),
	Q("c7-18", "ch7", "KBM 16", "medium", "The progressive statement of expenditure (KBM 16) is sent monthly to the Secretariat —", [
		"on the 1st of the same month",
		"by the end of the following month",
		"after PAC approval",
		"only in March"
	], 1, "അടുത്ത മാസം അവസാനത്തോടെ Secretariat-ലേക്ക്. നിയന്ത്രണം കാലതാമസമില്ലാതെ.", "By the end of the following month.", ["forms", "dates"]),
	Q("c7-19", "ch7", "KBM 17-18", "medium", "Forms KBM 17 and KBM 18 relate to monthly/progressive expenditure of —", [
		"Forest Department only",
		"Public Works Department (division and circle)",
		"Education Department",
		"KPSC"
	], 1, "KBM 17 PWD divisional monthly; KBM 18 circle progressive.", "PWD division (17) and circle (18).", ["forms", "pwd"]),
	Q("c7-20", "ch7", "KBM 19", "medium", "Forest divisional progressive statement (KBM 19) is sent to the Conservator by —", [
		"the 8th of the following month",
		"the 18th",
		"the 28th",
		"31st March only"
	], 0, "KBM 19: Conservator-ന് 8-നകം. KBM 21 circle consolidate: CCF-ന് 18-നകം.", "To the Conservator by the 8th.", ["forest", "dates"]),
	Q("c7-21", "ch7", "KBM 21", "medium", "Circle consolidation for Forest (KBM 21) goes to the Chief Conservator of Forests by —", [
		"the 8th",
		"the 18th",
		"the 28th",
		"the end of the quarter"
	], 1, "CCF-ന് 18-ാം തീയതി.", "To CCF by the 18th.", ["forest"]),
	Q("c7-22", "ch7", "74", "hard", "A CCO stationed outside Thiruvananthapuram should send an extract of accounts to the Accountant General by —", [
		"the 8th of the following month",
		"the 18th",
		"the 28th of the following month",
		"15th September"
	], 2, "തിരുവനന്തപുരത്തിന് പുറത്തുള്ള CCO: AG-യ്ക്ക് extract അടുത്ത മാസം 28-നകം.", "Extract to AG by the 28th of the following month.", ["reconciliation"]),
	Q("c7-23", "ch7", "75-76", "medium", "If AG's figures of expenditure are higher than the departmental figures pending reconciliation, the CCO should, for control purposes, adopt —", [
		"the departmental figures",
		"the AG's figures",
		"the average of the two",
		"zero until PAC decides"
	], 1, "AG കൂടുതലെങ്കിൽ നിയന്ത്രണത്തിന് AG കണക്ക്. പിന്നീട് reconcile ചെയ്യുക. റവന്യൂവും ചെലവും reconcile ചെയ്യണം.", "Use AG's (higher) figures for control pending reconciliation.", ["reconciliation"]),
	Q("c7-24", "ch7", "76", "medium", "Expenditure from the Contingency Fund is reconciled —", [
		"along with Consolidated Fund as one total",
		"separately (Rule 11 of the Kerala Contingency Fund Rules, 1957)",
		"never",
		"only after excess grant"
	], 1, "KCF Rules 1957 Rule 11: Contingency Fund ചെലവ് പ്രത്യേകം reconcile.", "Separately, under Rule 11 of the 1957 Rules.", ["contingency-fund"]),
	Q("c7-25", "ch7", "78", "medium", "PWD, PHE and Forest draw funds by —", [
		"treasury bills only, like other civil departments",
		"cheques, and compile accounts to the Accountant General",
		"cash from Contingency Fund",
		"PAC authorisation"
	], 1, "ഈ വകുപ്പുകൾ ചെക്ക് വലിക്കുന്നു; അക്കൗണ്ട് AG-യ്ക്ക് compile ചെയ്യുന്നു. LoC ഇതിനോട് ബന്ധപ്പെട്ടിരിക്കുന്നു.", "They draw cheques and compile accounts to AG.", ["pwd"]),
	Q("c7-26", "ch7", "KBM 20", "easy", "Form KBM 20 is the statement of expenditure on —", [
		"sanctioned works in a Forest district for the month",
		"number of officers on DA",
		"draft paragraphs",
		"charged salaries of Judges"
	], 0, "KBM 20: Forest ജില്ലയിലെ sanctioned works — മാസ ചെലവ്.", "Forest district sanctioned works, monthly.", ["forms"]),
	Q("c7-27", "ch7", "73", "medium", "Gazetted officers' personal claims should be intimated monthly to —", [
		"the PAC",
		"the Controlling Officers",
		"the Governor",
		"the Estimates Committee"
	], 1, "ഗസറ്റഡ് personal claims മാസംതോറും CO-കളെ അറിയിക്കുക — appropriation control-ന്.", "Monthly to Controlling Officers.", ["gazetted"]),
	Q("c7-28", "ch7", "71", "medium", "There should be no rush of expenditure in —", [
		"April",
		"the closing months of the year",
		"July when the circular issues",
		"September"
	], 1, "വർഷാവസാന ധാന്യം ചെലവ് നിരുത്സാഹപ്പെടുത്തുന്നു. മിച്ചം നേരത്തെ സറണ്ടർ ചെയ്യുക; റിസർവായി വയ്ക്കരുത്.", "No rush of expenditure in the closing months.", ["rush"])
];
var ch8 = [
	Q("c8-01", "ch8", "83", "easy", "Reappropriation between minor heads within a grant is the exclusive power of —", [
		"the Chief Controlling Officer",
		"the Finance Department",
		"the Accountant General",
		"the PAC"
	], 1, "Minor heads-നിടയിൽ (ഒരേ ഗ്രാന്റ്) FD മാത്രം. Minor-ന് കീഴിലുള്ള heads: Admin Dept + App 9 col.4 CCOs.", "FD exclusively reappropriates between minor heads within a grant.", ["reappropriation"]),
	Q("c8-02", "ch8", "83", "medium", "Administrative Departments and specified CCOs may reappropriate —", [
		"between two grants",
		"between heads subordinate to a minor head",
		"from charged to voted",
		"from revenue to capital"
	], 1, "Minor-ന് താഴെയുള്ള heads-നിടയിൽ Admin/CCO. നിരവധി നിബന്ധനകൾ ഉണ്ട്.", "Between heads subordinate to a minor head.", ["reappropriation"]),
	Q("c8-03", "ch8", "84", "easy", "Reappropriation is forbidden between —", [
		"two detailed heads under the same minor head (always)",
		"grants; charged and voted; revenue and capital; and for a New Service",
		"two object heads of office expenses",
		"temporary and permanent salaries of the same office"
	], 1, "നിരോധനം: ഗ്രാന്റുകൾക്കിടയിൽ; charged↔voted; revenue↔capital; New Service-ന്. ഇത് ഹൈ-ഫ്രീക്വൻസി ചോദ്യം.", "Not between grants, charged/voted, revenue/capital, or for a New Service.", ["reappropriation"]),
	Q("c8-04", "ch8", "84", "medium", "The amount of a reappropriation should be a multiple of —", [
		"Rs 1",
		"Rs 10",
		"Rs 100",
		"Rs 1,000"
	], 2, "Rs 100-ന്റെ ഗുണിതം. എസ്റ്റിമേറ്റ് rounding-നോട് യോജിക്കുന്നു.", "Multiple of Rs 100.", ["reappropriation"]),
	Q("c8-05", "ch8", "85", "hard", "Excess or saving of Rs 100 or less under a unit —", [
		"must always be regularised by excess grant",
		"need not be regularised if the grant as a whole is not exceeded and the unit was not reduced by the Legislature",
		"is a New Service",
		"is charged automatically"
	], 1, "≤ Rs 100: ഗ്രാന്റ് മൊത്തം കവിഞ്ഞിട്ടില്ലെങ്കിൽ, നിയമസഭ യൂണിറ്റ് കുറച്ചിട്ടില്ലെങ്കിൽ, regularise വേണ്ട.", "Trivial excess/saving ≤ Rs 100 need not be regularised under those conditions.", ["excess"]),
	Q("c8-06", "ch8", "84", "medium", "Funds cannot be reappropriated to an object which has —", [
		"a detailed head",
		"no original or supplementary provision, unless FD has already reappropriated to it",
		"a CCO",
		"a minor head"
	], 1, "Original/Supplementary provision ഇല്ലാത്ത object-ലേക്ക്, FD ആദ്യം reappropriate ചെയ്തിട്ടില്ലെങ്കിൽ, പറ്റില്ല.", "No reappropriation to a head with nil original/supplementary provision unless FD has already provided by reappropriation.", ["reappropriation"]),
	Q("c8-07", "ch8", "84", "medium", "Reappropriation from Plan to Non-Plan or from Centrally Sponsored schemes without FD is —", [
		"freely allowed to CCOs",
		"not allowed",
		"allowed up to Rs 10,000",
		"allowed in March only"
	], 1, "Plan → Non-Plan, Centrally Sponsored മാറ്റം FD കൂടാതെ നിരോധിതം.", "Not allowed without FD.", ["plan"]),
	Q("c8-08", "ch8", "86", "hard", "After the Legislature or a higher authority has reduced a head, a subordinate authority —", [
		"may freely restore the amount by reappropriation",
		"cannot increase it without prior consent of the reducing authority",
		"may use Contingency Fund as token",
		"need only inform the Treasury"
	], 1, "കുറച്ച തുക താഴേത്തട്ട് സ്വയം തിരിച്ചുകൂട്ടരുത്.", "Cannot increase a reduced head without the reducing authority's consent.", ["reappropriation"]),
	Q("c8-09", "ch8", "86", "hard", "In PWD/PHE, Superintending Engineer's power of reappropriation from/to a single head is —", [
		"Rs 10,000",
		"Rs 25,000",
		"Rs 5,00,000",
		"unlimited"
	], 1, "SE Rs 25,000; EE Rs 10,000; CE Rs 5,00,000 major work to major work (G.O.(P) 870/79/Fin 20-9-1979).", "SE: Rs 25,000; EE: Rs 10,000; CE: Rs 5 lakh (major to major).", ["pwd"]),
	Q("c8-10", "ch8", "86", "hard", "Executive Engineer's reappropriation limit from/to a single head (PWD/PHE) is —", [
		"Rs 2,500",
		"Rs 10,000",
		"Rs 25,000",
		"Rs 1 lakh"
	], 1, "EE Rs 10,000.", "EE: Rs 10,000.", ["pwd"]),
	Q("c8-11", "ch8", "86", "hard", "Chief Engineer's power to reappropriate from one major work to another is —", [
		"Rs 25,000",
		"Rs 1 lakh",
		"Rs 5,00,000",
		"Rs 20 lakh"
	], 2, "CE: Rs 5 lakh, major work → major work. G.O.(P) 870/79/Fin 20-9-1979.", "CE: Rs 5,00,000.", ["pwd"]),
	Q("c8-12", "ch8", "86", "medium", "From 1 April 1974 each project is a minor head. Therefore reappropriation between projects —", [
		"is freely done by EEs",
		"cannot be done by authorities other than FD (as between minor heads)",
		"is done by PAC",
		"is automatic"
	], 1, "പ്രോജക്റ്റ് = minor head. Minor-നിടയിൽ FD മാത്രം. അതുകൊണ്ട് പ്രോജക്റ്റുകൾക്കിടയിൽ CCO reappropriate ചെയ്യരുത്.", "No reappropriation between projects except by FD.", ["projects"]),
	Q("c8-13", "ch8", "86", "hard", "An exception allows new minor works up to — even if there is no budget provision.", [
		"Rs 1,000",
		"Rs 2,500",
		"Rs 10,000",
		"Rs 1 lakh"
	], 1, "പുതിയ minor works Rs 2,500 വരെ, ബജറ്റ് പ്രൊവിഷൻ ഇല്ലെങ്കിലും (നിബന്ധനകളോടെ).", "New minor works up to Rs 2,500 without provision — exception.", ["works"]),
	Q("c8-14", "ch8", "86", "medium", "Funds should not be reappropriated for works which are —", [
		"in the Works Appendix",
		"not in the Works Appendix",
		"major works in the same project",
		"maintenance of existing buildings in the appendix"
	], 1, "Works Appendix-ൽ ഇല്ലാത്ത വർക്കിന് ഫണ്ട് മാറ്റരുത്. വകുപ്പുകളുടെ വർക്കുകൾക്കിടയിലും മാറ്റരുത്.", "No funds for works not in the Works Appendix.", ["works"]),
	Q("c8-15", "ch8", "KBM 22", "easy", "Form KBM 22 is the form of application/sanction for —", [
		"letter of credit",
		"reappropriation of funds",
		"draft paragraph reply",
		"vote on account"
	], 1, "KBM 22 = reappropriation. Charged/voted, revenue/capital എന്നിവയ്ക്ക് പ്രത്യേക ഫോം. കാരണം പൂർണ്ണമായി, PAC/Appropriation Accounts-ന്.", "KBM 22: reappropriation of funds.", ["forms"]),
	Q("c8-16", "ch8", "87-88", "easy", "Supplementary grants are obtained under —", [
		"Article 202",
		"Article 204",
		"Article 205",
		"Article 267"
	], 2, "Art. 205: (i) അനുവദിച്ച തുക അപര്യാപ്തം (ii) New Service. CCO ആദ്യ ഉത്തരവാദിത്വം.", "Article 205: insufficient authorised amount, or New Service.", ["supplementary"]),
	Q("c8-17", "ch8", "88", "medium", "The House should be satisfied that a supplementary demand was —", [
		"foreseeable in July itself",
		"unforeseeable and cannot be postponed",
		"desired by the CCO for convenience",
		"needed to avoid surrender"
	], 1, "മുൻകൂട്ടി കാണാൻ കഴിയാത്തത്; മാറ്റിവയ്ക്കാൻ പറ്റാത്തത്. അല്ലെങ്കിൽ യഥാർഥ ബജറ്റിൽ വയ്ക്കാമായിരുന്നു.", "Unforeseeable and cannot be postponed.", ["supplementary"]),
	Q("c8-18", "ch8", "89", "easy", "Copies of the Supplementary Appropriation Act should be sent to —", [
		"the PAC only",
		"the Accountant General",
		"every village office",
		"the Election Commission"
	], 1, "സപ്ലിമെന്ററി ആക്ട് കോപ്പി AG-യ്ക്ക് — അക്കൗണ്ട് താരതമ്യത്തിന്.", "Copies to the Accountant General.", ["supplementary"]),
	Q("c8-19", "ch8", "90", "easy", "Savings, as soon as foreseen, should be —", [
		"held as a secret reserve for March",
		"surrendered immediately through the Administrative Department to FD",
		"reappropriated to another grant",
		"credited to Contingency Fund by the DO"
	], 1, "മിച്ചം കണ്ടാൽ ഉടൻ സറണ്ടർ. റിസർവായി വയ്ക്കരുത്. അവസാന മാസങ്ങളിലെ തിടുക്ക ചെലവ് വേണ്ട.", "Surrender immediately when foreseen; do not hold in reserve.", ["surrender"]),
	Q("c8-20", "ch8", "91", "medium", "The last date for Administrative Departments to send surrender/reappropriation proposals is —", [
		"15th January",
		"15th February",
		"25th February",
		"31st March"
	], 1, "Admin: ഫെബ്രുവരി 15. FD: ഫെബ്രുവരി 25. Irrigation capital outlay statement-ഉം ഫെബ്രുവരി 25.", "Admin Depts: 15 February; FD: 25 February.", ["dates"]),
	Q("c8-21", "ch8", "91", "medium", "Surrender/reappropriation proposals should reach Finance Department by —", [
		"15th February",
		"25th February",
		"15th March",
		"30th November"
	], 1, "FD-യ്ക്ക് ഫെബ്രുവരി 25.", "25 February.", ["dates"]),
	Q("c8-22", "ch8", "92", "medium", "On receiving surrenders, Finance Department generally —", [
		"returns them to DOs for March spending",
		"(i) offsets reductions already made for probable savings, (ii) reappropriates remaining to excesses, (iii) resumes the rest",
		"credits PAC",
		"votes an excess grant immediately"
	], 1, "Resumption ക്രമം: probable-savings കുറവ് ക്രമീകരിക്കുക → excess-ലേക്ക് reappropriate → ബാക്കി resume. Charged/voted, revenue/capital വേറെ നിർത്തുക. പിന്നീട് FD revoke ചെയ്യാം.", "Offset probable-savings cuts, reappropriate to excesses, resume the rest.", ["resumption"]),
	Q("c8-23", "ch8", "94", "easy", "Expenditure on a New Service, even from savings, cannot be incurred before —", [
		"a Warning Slip",
		"a supplementary vote (token if savings exist) or a Contingency Fund advance in urgency",
		"the RE is printed",
		"an Estimates Committee tour"
	], 1, "മിച്ചമുണ്ടെങ്കിലും New Service-ന് വോട്ട് വേണം (token Rs 100). അടിയന്തരം: Contingency Fund മുഴുവൻ തുക.", "Need supplementary vote (or CF advance if urgent). Savings alone are not enough.", ["new-service"]),
	Q("c8-24", "ch8", "94", "medium", "A 'New form of service' (altogether new policy/facility) requires the vote of the Legislature —", [
		"only if cost exceeds Rs 25 lakh",
		"irrespective of financial implications, if not contemplated in the AFS",
		"never, if savings exist",
		"only if PAC so directs after the year"
	], 1, "Altogether new service: തുക എത്ര ചെറുതായാലും വോട്ട് വേണം. New instrument of service: തുക വലുതെങ്കിൽ അതേപോലെ (App 13).", "Altogether new services need a vote irrespective of cost.", ["new-service"]),
	Q("c8-25", "ch8", "94", "medium", "Opening of a new school is typically treated as —", [
		"never a New Service",
		"a New Instrument of Service / New Service attracting legislative vote when criteria apply",
		"charged expenditure",
		"a Public Account transaction"
	], 1, "പുതിയ സ്കൂൾ = നിലവിലെ സേവനത്തിന്റെ വിപുലീകരണം (new instrument). പഴയ ഉദാഹരണം: extra peon സാധാരണ New Service അല്ല.", "A new school is a classic New Service / new instrument example.", ["new-service"]),
	Q("c8-26", "ch8", "95", "easy", "The Contingency Fund of Kerala is constituted under the Kerala Contingency Fund Act, —", [
		"1950",
		"1957",
		"1966",
		"1974"
	], 1, "KCF Act 1957, Rules 1957, App 14. FD administer ചെയ്യുന്നു; imprest ഗവർണറോടൊപ്പം. നിയമസഭാ നിയന്ത്രണം കുറയുന്നില്ല.", "Kerala Contingency Fund Act, 1957. Appendix 14.", ["contingency-fund"]),
	Q("c8-27", "ch8", "95", "medium", "An order of advance from the Contingency Fund —", [
		"lapses at the close of the financial year",
		"does not lapse with the year; it lapses on passing of the Supplementary Appropriation",
		"lasts ten years",
		"is the same as a token grant"
	], 1, "വർഷം കഴിഞ്ഞിട്ടും advance നിലനിൽക്കും; Supplementary പാസായാൽ lapse — ഫണ്ട് വീണ്ടും നിറയ്ക്കുന്നു.", "Does not lapse with the year; lapses when Supplementary is passed.", ["contingency-fund"]),
	Q("c8-28", "ch8", "97", "easy", "An excess grant is voted —", [
		"in July with the budget circular",
		"after the close of the year, to regularise excess over the authorised grant",
		"by the CCO",
		"instead of the Appropriation Act"
	], 1, "വർഷം കഴിഞ്ഞ് Art. 205. ക്രമക്കേടാണ്. നടപടി App 15. Appropriation Accounts വഴി PAC കാണുന്നു.", "After the year, to regularise excess. Irregular. Appendix 15.", ["excess"]),
	Q("c8-29", "ch8", "84", "medium", "Reappropriation should not create a recurring liability extending beyond the year unless —", [
		"the DO agrees",
		"FD has sanctioned it",
		"AG issues a Warning Slip",
		"it is under Rs 100"
	], 1, "വർഷം കടന്ന് recurring liability FD അനുമതിയില്ലാതെ വേണ്ട.", "No recurring liability beyond the year unless FD sanctions it.", ["reappropriation"]),
	Q("c8-30", "ch8", "83-86", "medium", "Reasons for reappropriation should be —", [
		"brief and vague to save time",
		"full, frank and specific, because they appear in Appropriation Accounts and before PAC",
		"marked secret from AG",
		"in French only"
	], 1, "PAC/Appropriation Accounts-ൽ കാരണം വരും. മറച്ചുവയ്ക്കരുത്.", "Full, frank, specific reasons for PAC/Appropriation Accounts.", ["reappropriation"])
];
var ch9 = [
	Q("c9-01", "ch9", "98", "easy", "Financial accountability of the Executive to the Legislature is secured primarily through —", [
		"the budget circular of July",
		"the Audit Reports of the Comptroller and Auditor General",
		"letters of credit",
		"number statements KBM 1–7"
	], 1, "CAG-യുടെ Audit Reports + PAC/COPU പരിശോധന = ധനപരമായ ഉത്തരവാദിത്വം. Art. 151(2): റിപ്പോർട്ട് ഗവർണർ നിയമസഭയിൽ വയ്ക്കുന്നു.", "CAG Audit Reports examined by PAC/COPU.", ["cag"]),
	Q("c9-02", "ch9", "98", "easy", "Audit Reports of the CAG relating to the State are laid before the Legislature under —", [
		"Article 112",
		"Article 148",
		"Article 151(2)",
		"Article 266"
	], 2, "Art. 151(2): സംസ്ഥാന ഓഡിറ്റ് റിപ്പോർട്ട് ഗവർണർ സഭയിൽ വയ്ക്കുന്നു. (കേന്ദ്രം 151(1), രാഷ്ട്രപതി).", "Article 151(2).", ["article-151"]),
	Q("c9-03", "ch9", "99", "medium", "Appropriation Accounts are prepared by the CAG under —", [
		"section 11 of the CAG's (DPC) Act, 1971, compared with Appropriation Acts under Articles 204–205",
		"Article 202 alone",
		"the Kerala Contingency Fund Act",
		"Rule 231 of Assembly Rules only"
	], 0, "CAG Act 1971 s.11: Appropriation Accounts. Arts 204–205-ലെ Acts-മായി താരതമ്യം — എത്ര അനുവദിച്ചു, എത്ര ചെലവഴിച്ചു.", "s.11 CAG Act 1971; compared with Appropriation Acts (Arts 204–205).", ["appropriation-accounts"]),
	Q("c9-04", "ch9", "100-101", "easy", "A Draft Paragraph is sent by the Accountant General to —", [
		"every Disbursing Officer",
		"the Secretary to Government by name, with copies to Finance Secretary and Head of Department",
		"the Speaker only",
		"the press"
	], 1, "Draft para: AG → Secretary (by name). കോപ്പി FD Secretary + HoD. Demiofficial, അഡ്രസ്സിക്ക് തന്നെ.", "To the Secretary by name; copies to FD Secretary and HoD.", ["draft-para"]),
	Q("c9-05", "ch9", "101", "easy", "Reply to a Draft Paragraph should be sent within —", [
		"two weeks",
		"six weeks",
		"six months",
		"one year"
	], 1, "6 ആഴ്ചയ്ക്കകം മറുപടി. അന്തിമം 3 മാസത്തിനകം. അല്ലെങ്കിൽ para അന്തിമമായി കണക്കാക്കും.", "Reply within 6 weeks; final within 3 months.", ["draft-para", "dates"]),
	Q("c9-06", "ch9", "101", "medium", "If no final reply is sent within three months, the Draft Paragraph is —", [
		"dropped",
		"treated as final",
		"sent to the Supreme Court",
		"converted to a charged item"
	], 1, "3 മാസം മറുപടി ഇല്ലെങ്കിൽ para final. സമയം പാലിക്കുക.", "Treated as final.", ["draft-para"]),
	Q("c9-07", "ch9", "102", "medium", "In replies to Draft Paragraphs, the department should agree on —", [
		"the language of criticism",
		"the facts, though not necessarily the language",
		"nothing, as a matter of policy",
		"only the amount of surcharge"
	], 1, "വസ്തുതകളിൽ യോജിപ്പ്; ഭാഷയിൽ നിർബന്ധമില്ല. വ്യക്തിനാമം ഒഴിവാക്കുക — designation മതി.", "Agree on facts, not necessarily language. Avoid names of individuals.", ["draft-para"]),
	Q("c9-08", "ch9", "103", "medium", "A senior officer not below the rank of Deputy Secretary should watch the Draft Paragraph register on —", [
		"the last Friday of the year",
		"the first working day of every month",
		"only when PAC summons",
		"April 1 only"
	], 1, "ഓരോ മാസത്തെ ആദ്യ പ്രവൃത്തിദിനം Dy Secretary+ രജിസ്റ്റർ നോക്കണം. കാലതാമസം 6–12 മാസം PAC വരെ.", "First working day of the month.", ["draft-para"]),
	Q("c9-09", "ch9", "105", "medium", "Action-taken statement on PAC recommendations, after Audit vetting, should go to PAC within —", [
		"two weeks",
		"two months",
		"one year",
		"the next five-year plan"
	], 1, "Audit vetting ശേഷം 2 മാസത്തിനകം PAC-യ്ക്ക് action taken. App 15 നിർദേശങ്ങൾ.", "Within 2 months after Audit vetting.", ["pac"]),
	Q("c9-10", "ch9", "104", "medium", "The usual time-lag from the transactions to examination by PAC is about —", [
		"one week",
		"six to twelve months",
		"ten years",
		"until the next general election only"
	], 1, "6–12 മാസം. അതുകൊണ്ട് ഫയൽ/മറുപടി ക്രമത്തിൽ സൂക്ഷിക്കണം.", "About 6–12 months.", ["pac"]),
	Q("c9-11", "ch9", "98", "medium", "The three instruments of legislative review mentioned in the Manual are —", [
		"FD, FD Budget Wing, and Treasuries",
		"CAG audit with PAC, COPU, and the Estimates Committee",
		"LoC, Appropriation Control, and KBM 12",
		"Part I, Part II, and RE"
	], 1, "Review: CAG+PAC, COPU (undertakings), Estimates Committee (എസ്റ്റിമേറ്റ്/സമ്പദ്‌വ്യവസ്ഥ).", "PAC (with CAG), COPU, Estimates Committee.", ["review"]),
	Q("c9-12", "ch9", "App 15", "easy", "Instructions for departments on PAC matters are in —", [
		"Appendix 11",
		"Appendix 13",
		"Appendix 15",
		"Appendix 17"
	], 2, "App 15: Draft paras, PAC നോട്ടുകൾ, സമയപരിധി.", "Appendix 15.", ["pac"])
];
var more = [
	Q("m-01", "ch1", "Preface", "medium", "The third edition of the Kerala Budget Manual incorporates amendments issued up to —", [
		"30 June 1977",
		"30 June 1982",
		"15 September 1999",
		"1 April 1974"
	], 1, "മൂന്നാം പതിപ്പ്: 1977 ഏപ്രിൽ പതിപ്പിലെ തിരുത്തുകൾ 30-6-1982 വരെ. പ്രസിദ്ധീകരണ കുറിപ്പ് 2-3-1985, K.V. Rabindran Nair.", "Corrections up to 30 June 1982.", ["preface"]),
	Q("m-02", "ch1", "Preface", "medium", "The second edition preface is dated 19 April 1977 and signed by —", [
		"C. Thomas",
		"K. V. Rabindran Nair",
		"Vinod Rai",
		"G. Jeothi"
	], 1, "രണ്ടാം പതിപ്പ്: K.V. Rabindran Nair, Special Secretary (Finance), 19 Apr 1977. ഒന്നാം പതിപ്പ് C. Thomas, March 1966.", "K. V. Rabindran Nair.", ["preface"]),
	Q("m-03", "ch1", "Preface", "hard", "Appendix 13 (Rulings on New Service) was substituted by G.O.(P) No. —", [
		"49/74/Fin",
		"46/74/Fin",
		"1803/99/Fin dated 15 September 1999",
		"870/79/Fin"
	], 2, "PAC 1998-2000 38-ാം റിപ്പോർട്ട്. G.O.(P) 1803/99/Fin, 15 Sep 1999. C.S. No. 1/99. Vinod Rai, Principal Secretary (Finance).", "G.O.(P) 1803/99/Fin dated 15 September 1999.", ["new-service"]),
	Q("m-04", "ch1", "9", "hard", "The first digit of a major-head code indicates —", [
		"the object of expenditure",
		"the section to which the head belongs (receipts, revenue expenditure, capital, etc.)",
		"the treasury",
		"whether the item is charged"
	], 1, "ആദ്യ അക്കം സെക്ഷൻ: 0 = റവന്യൂ വരവ്, 2 = റവന്യൂ ചെലവ്, 4 = ക്യാപിറ്റൽ, 6 = debt/loans, 8 = CF/Public Account.", "The first digit shows the section of accounts.", ["coding"]),
	Q("m-05", "ch1", "9", "medium", "Under major head '280. Medical', the two sub-major heads illustrated are —", [
		"A. Allopathy and B. Other Systems of Medicine",
		"A. Tax and B. Non-tax",
		"Plan and Non-plan",
		"Voted and Charged"
	], 0, "Sub-major head ഉദാഹരണം: 280 Medical — A Allopathy, B Other Systems.", "A. Allopathy and B. Other Systems of Medicine.", ["sub-major"]),
	Q("m-06", "ch1", "8", "medium", "Government accounts are kept on the principle of recording —", [
		"only net transactions after recoveries",
		"gross transactions",
		"only cash in treasuries",
		"only voted items"
	], 1, "Gross transactions. Recoveries പ്രത്യേകം; വോട്ട് gross. (Netting കൊണ്ട് നിയമസഭാ നിയന്ത്രണം മറയരുത്).", "Gross transactions.", ["gross-vote"]),
	Q("m-07", "ch3", "17", "hard", "Which is generally an exception from Part II treatment?", [
		"Recurring grant-in-aid expansion",
		"Making existing temporary posts permanent",
		"New machinery on a large scale",
		"Loans for a new object"
	], 1, "താൽക്കാലികം സ്ഥിരമാക്കൽ, താൽക്കാലിക തസ്തിക തുടരൽ, fully recovered cost, PWD temporary for original/minor works ≤ Rs 2,500 — Part II ഒഴിവുകൾ.", "Making temporary posts permanent is listed among Part II exceptions.", ["part-ii"]),
	Q("m-08", "ch3", "17", "medium", "Loans for new works or a new object are treated as —", [
		"Part I",
		"Part II",
		"always charged",
		"Public Account only"
	], 1, "പുതിയ വർക്ക്/പുതിയ ഉദ്ദേശ്യത്തിനുള്ള ലോൺ = Part II.", "Part II.", ["part-ii"]),
	Q("m-09", "ch6", "Art 204", "easy", "No money shall be withdrawn from the Consolidated Fund of the State except under appropriation made by law. This is —", [
		"Article 202",
		"Article 204",
		"Article 206",
		"Article 267"
	], 1, "Art. 204: Appropriation by law ഇല്ലാതെ CF-ൽ നിന്ന് പണം എടുക്കരുത്. App 13-ലും ഉദ്ധരിക്കുന്നു.", "Article 204.", ["article-204"]),
	Q("m-10", "ch6", "Art 205", "easy", "Supplementary, additional or excess grants are dealt with in —", [
		"Article 202",
		"Article 204",
		"Article 205",
		"Article 151"
	], 2, "Art. 205: വർഷത്തിനിടെ അധിക/പുതിയ സേവനം; വർഷം കഴിഞ്ഞ് excess.", "Article 205.", ["article-205"]),
	Q("m-11", "ch7", "App 11", "medium", "Appropriation Control was introduced by —", [
		"G.O.(P) 46/74/Fin dated 27 February 1974",
		"G.O.(P) 49/74/Fin dated 1 March 1974",
		"G.O.(MS) 451/80/Fin",
		"G.O.(P) 1803/99/Fin"
	], 1, "Appropriation Control: G.O.(P) 49/74/Fin 1 Mar 1974, App 11. LoC: G.O.(P) 46/74/Fin 27 Feb 1974, App 12.", "G.O.(P) 49/74/Fin dated 1 March 1974.", ["appropriation-control"]),
	Q("m-12", "ch7", "App 12", "medium", "The Letter of Credit system was introduced by —", [
		"G.O.(P) 46/74/Fin dated 27 February 1974",
		"G.O.(P) 49/74/Fin dated 1 March 1974",
		"G.O.(P) 1803/99/Fin",
		"Circular 72/76/Fin"
	], 0, "LoC G.O.(P) 46/74/Fin 27 Feb 1974. Harbour Engg later G.O.(MS) 451/80/Fin 15 Jul 1980.", "G.O.(P) 46/74/Fin dated 27 February 1974.", ["loc"]),
	Q("m-13", "ch8", "91", "medium", "Irrigation capital outlay statement should reach Finance Department by —", [
		"15th February",
		"25th February",
		"15th September",
		"30th November"
	], 1, "Irrigation capital outlay statement: ഫെബ്രുവരി 25 (FD surrender തീയതിയോടൊപ്പം).", "25 February.", ["dates"]),
	Q("m-14", "ch9", "102", "medium", "In Audit paragraphs, names of individual officers should —", [
		"always be printed in bold",
		"be avoided; designation only should be used",
		"be sent to newspapers first",
		"replace the draft paragraph"
	], 1, "വ്യക്തിനാമം ഒഴിവാക്കുക; designation മതി.", "Avoid names; use designation only.", ["draft-para"]),
	Q("m-15", "ch9", "101", "medium", "Communications on Draft Paragraphs are sent —", [
		"as ordinary circulars to the section",
		"demiofficial, addressed to the officer by name",
		"only through PAC",
		"by telegram to every DO"
	], 1, "D.O. letter, by name — ഉത്തരവാദിത്വം വ്യക്തിപരം.", "Demiofficial, by name.", ["draft-para"]),
	Q("m-16", "ch1", "Preface", "easy", "The Kerala Budget Manual replaced —", [
		"the Indian Financial Rules only",
		"the Travancore-Cochin Budget Manual, which should no longer be cited",
		"the Constitution of India",
		"the Kerala Treasury Code entirely"
	], 1, "T-C Budget Manual പകരം; ഇനി അത് ഉദ്ധരിക്കരുത്. ഒന്നാം പതിപ്പ് preface.", "It replaces the Travancore-Cochin Budget Manual.", ["preface"]),
	Q("m-17", "ch1", "Preface", "medium", "The Manual was rewritten in a simple style especially considering —", [
		"tourists",
		"new entrants who have to take departmental examinations",
		"only PAC members",
		"school children"
	], 1, "രണ്ടാം പതിപ്പ് preface: departmental test എഴുതുന്ന പുതിയ ഉദ്യോഗസ്ഥർക്ക് ലളിതമായി.", "New entrants taking departmental examinations.", ["preface"]),
	Q("m-18", "ch2", "11", "medium", "The Consolidated Fund of the State is referred to in —", [
		"Article 112 only",
		"Article 266",
		"Article 151 only",
		"Article 322 only"
	], 1, "Art. 266: Consolidated Fund / Public Account. CF-ൽ നിന്ന് പിൻവലിക്കാൻ Art. 204 appropriation വേണം.", "Article 266.", ["article-266"]),
	Q("m-19", "app", "App 13", "hard", "Cost of acquisition of land is a New Service (revised App 13) when it exceeds —", [
		"Rs 2 lakh",
		"Rs 5 lakh",
		"Rs 20 lakh (non-recurring)",
		"Rs 25 lakh recurring"
	], 2, "Lands: Rs 20 lakh non-recurring-ന് മുകളിൽ New Service.", "Rs 20 lakh non-recurring.", ["new-service"]),
	Q("m-20", "app", "App 13", "hard", "Write-off of loans: New Service limit is —", [
		"Rs 25,000",
		"Rs 2 lakh",
		"Rs 20 lakh",
		"Rs 25 lakh"
	], 1, "ലോൺ write-off-ന് revenue grant appropriation വേണം; NS പരിധി Rs 2 lakh.", "Rs 2 lakh.", ["new-service"]),
	Q("m-21", "app", "App 13", "hard", "Interest-free loans to Scheduled Castes/Scheduled Tribes become New Service when the loan exceeds —", [
		"Rs 2 lakh",
		"Rs 5 lakh",
		"Rs 10 lakh",
		"Rs 25 lakh"
	], 1, "SC/ST interest-free loans: Rs 5 lakh-ന് മുകളിൽ NS. മറ്റ് interest-bearing advances (10/12 ഒഴികെ) Rs 2 lakh.", "Rs 5 lakh.", ["new-service"]),
	Q("m-22", "app", "App 13", "hard", "Setting up of a new Government Company or amalgamation of two or more Government Companies —", [
		"is never New Service",
		"constitutes New Service",
		"is charged under Art. 290A",
		"is done by PAC resolution only"
	], 1, "പുതിയ കമ്പനി / ലയനം = New Service. ആദ്യ നിക്ഷേപവും NS.", "Constitutes New Service.", ["new-service"]),
	Q("m-23", "app", "App 13", "medium", "A scheme which was treated as New Service last year, acted upon, but for which no provision is made this year —", [
		"must again be treated as New Service",
		"need not be treated as New Service",
		"must go to COPU",
		"is an excess grant"
	], 1, "കഴിഞ്ഞ വർഷം NS ആയി നടപ്പാക്കിയ സ്കീം, ഇത്തവണ provision ഇല്ലെങ്കിലും വീണ്ടും NS അല്ല (General (i)).", "Need not be treated as New Service again.", ["new-service"]),
	Q("m-24", "app", "App 13", "medium", "Schemes with token provision under Non-Plan/State Plan, when actually sanctioned —", [
		"are New Service all over again",
		"need not be treated as New Service, but should be specifically included in supplementary estimates",
		"lapse",
		"become charged"
	], 1, "Token provision ഉണ്ടെങ്കിൽ sanction New Service അല്ല; supplementary-യിൽ പ്രത്യേകം കാണിക്കുക.", "Not New Service; include specifically in supplementary estimates.", ["new-service"]),
	Q("m-25", "ch5", "51", "easy", "Which document commonly explains the budget figures in narrative form?", [
		"Warning Slip",
		"Explanatory Memorandum",
		"KBM 12",
		"Letter of Credit"
	], 1, "Explanatory Memorandum: ബജറ്റ് കണക്കുകളുടെ വിവരണം; ആസ്തി-ബാധ്യത അനുബന്ധം.", "Explanatory Memorandum.", ["documents"]),
	Q("m-26", "ch8", "86", "medium", "There should be no transfer of funds between —", [
		"two detailed heads under the same scheme when FD permits",
		"works of different departments",
		"object heads after FD reappropriation",
		"units that both have provision, within CCO power"
	], 1, "വ്യത്യസ്ത വകുപ്പുകളുടെ വർക്കുകൾക്കിടയിൽ ഫണ്ട് മാറ്റരുത്.", "No transfer between different departments' works.", ["works"]),
	Q("m-27", "ch7", "64", "medium", "Control must ensure that expenditure on a service does not at any time exceed —", [
		"the Revised Estimate",
		"the budget grant as a whole",
		"last year's actuals",
		"the cash in a particular treasury"
	], 1, "ഒരു സേവനത്തിന്റെ ഗ്രാന്റ് മൊത്തം കവിയരുത്. Medical ഉദാഹരണം Ch I-ൽ.", "The budget grant as a whole.", ["control"]),
	Q("m-28", "ch1", "9", "medium", "Homogeneous schemes involving small outlay under a programme should be —", [
		"each given a new major head",
		"grouped into suitable sub-heads",
		"omitted from accounts",
		"charged"
	], 1, "ചെറിയ homogeneous സ്കീമുകൾ ഒരുമിച്ച് sub-head. Sub-heads അനാവശ്യമായി പെരുപ്പിക്കരുത്.", "Grouped into suitable sub-heads; do not multiply sub-heads.", ["sub-head"]),
	Q("m-29", "ch1", "9", "hard", "If a new sub-head is needed after budget documents are printed, the Administrative Department should send proposals to —", [
		"PAC",
		"Finance Department for scrutiny and sanction",
		"the Speaker",
		"the Estimates Committee"
	], 1, "ബജറ്റ് അച്ചടിച്ചശേഷം പുതിയ sub-head: Admin → FD sanction. Detailed head: FD അല്ലെങ്കിൽ AG; copy AG-യ്ക്ക്.", "To Finance Department for scrutiny and sanction.", ["sub-head"]),
	Q("m-30", "ch4", "Preface", "medium", "The list of Disbursing Officers, formerly in an appendix of the Budget Manual, now belongs to —", [
		"the Kerala Treasury Code",
		"Appendix 17",
		"the Appropriation Act",
		"COPU rules"
	], 0, "Disbursing Officers ലിസ്റ്റ് KTC-യിലേക്ക് മാറ്റി — treasury-യുമായി ബന്ധപ്പെട്ടതുകൊണ്ട്.", "Moved to the Kerala Treasury Code.", ["preface"]),
	Q("m-31", "ch10", "108", "medium", "Finance Accounts (as distinct from Appropriation Accounts) are also examined by —", [
		"Estimates Committee only",
		"PAC",
		"COPU only",
		"the Governor in Council"
	], 1, "PAC: Appropriation Accounts + Finance Accounts + CAG reports.", "PAC examines Finance Accounts as well.", ["pac"]),
	Q("m-32", "ch6", "57", "medium", "The Appropriation Act specifies —", [
		"only the FM's speech highlights",
		"the maximum amount that may be spent on each service during the year",
		"the names of all DOs",
		"PAC membership"
	], 1, "ഓരോ സേവനത്തിനും പരമാവധി തുക — അതിൽ കവിയരുത്.", "Maximum amount that may be spent on each service.", ["appropriation-act"]),
	Q("m-33", "ch8", "95", "medium", "The Contingency Fund is in the nature of an imprest placed at the disposal of —", [
		"the Speaker",
		"the Governor",
		"the CAG",
		"the PAC Chairman"
	], 1, "Imprest ഗവർണറോടൊപ്പം; FD administer ചെയ്യുന്നു. നിയമസഭാ നിയന്ത്രണം ഇല്ലാതാകുന്നില്ല — പിന്നീട് supplementary.", "Imprest with the Governor; administered by FD.", ["contingency-fund"]),
	Q("m-34", "ch3", "3", "easy", "Departmental estimates are scrutinised by Finance Department in the light of Administrative comments, AG actuals, and —", [
		"newspaper editorials",
		"information available with the Finance Department",
		"PAC minutes of ten years",
		"only the previous century's averages"
	], 1, "FD സൂക്ഷ്മ പരിശോധന: Admin comments, AG actuals, FD-യിലെ വിവരം. ആവശ്യമായിടത്ത് മാറ്റം; പുതിയ സ്കീമുകൾ പണം കണ്ടാൽ.", "Information available with FD, plus Admin comments and AG actuals.", ["estimates"]),
	Q("m-35", "ch1", "9", "medium", "Sectors are assigned a distinguishing prefix which is —", [
		"a Roman numeral",
		"a capital letter of the alphabet",
		"a four-digit code only",
		"the name of the Minister"
	], 1, "Sector = വലിയക്ഷരം A, B, C… Public Account വരെ N.", "A capital letter.", ["sector"]),
	Q("m-36", "app", "App 3", "medium", "Scholarships and Stipends form standard object number —", [
		"4",
		"8",
		"10",
		"26"
	], 2, "10. Scholarships and Stipends. LoC ഒഴിവിലും ഇവ.", "Object 10.", ["objects"]),
	Q("m-37", "app", "App 3", "easy", "Grants-in-aid/Contributions/Subsidies is standard object —", [
		"5",
		"9",
		"18",
		"24"
	], 1, "Object 9: GIA/Contributions/Subsidies. 1999-ൽ subsidy/GIA/contribution നിർവചനം App 13-ലും.", "Object 9.", ["objects"]),
	Q("m-38", "ch12", "110", "medium", "COPU is expected to see that public undertakings are run on —", [
		"purely charitable principles only",
		"sound business principles",
		"the same rules as treasuries",
		"cash basis without accounts"
	], 1, "Sound business principles — COPU-യുടെ കാതൽ. നയവും ദിനംപ്രതി ഭരണവും അല്ല.", "Sound business principles.", ["copu"]),
	Q("m-39", "ch8", "94", "medium", "Criteria for treating an item as New Service are determined based on the recommendation of —", [
		"the Estimates Committee",
		"the Public Accounts Committee",
		"the CAG alone without Government",
		"the Election Commission"
	], 1, "NS മാനദണ്ഡം PAC ശുപാർശ. ഇടയ്ക്ക് പുതുക്കണം. 1999-ൽ പുതുക്കി.", "Public Accounts Committee.", ["new-service"]),
	Q("m-40", "ch1", "Preface", "easy", "The Kerala Budget Manual is issued by —", [
		"the Law Department",
		"the Finance Department, by authority of the Government of Kerala",
		"the CAG as a code",
		"the Estimates Committee"
	], 1, "Finance Department, Government of Kerala. മുഖപ്പേജ്.", "Finance Department, Government of Kerala.", ["preface"])
];
var questions = [
	...ch1,
	...ch2,
	...ch3,
	...ch4,
	...ch5,
	...ch6,
	...ch7,
	...ch8,
	...ch9,
	...ch10,
	...ch11,
	...ch12,
	...app,
	...more
];
var byId = new Map(questions.map((q) => [q.id, q]));
function questionById(id) {
	return byId.get(id);
}
function questionsForChapter(id) {
	return questions.filter((q) => q.chapterId === id);
}
function chapterCounts() {
	const map = {};
	for (const c of chapters) map[c.id] = 0;
	for (const q of questions) map[q.chapterId] = (map[q.chapterId] ?? 0) + 1;
	return map;
}
var TOTAL_QUESTIONS = questions.length;
function searchQuestions(query) {
	const q = query.trim().toLowerCase();
	if (!q) return [];
	return questions.filter((item) => {
		return [
			item.question,
			item.explanationEn,
			item.explanationMl,
			item.para,
			...item.options,
			...item.tags
		].join(" ").toLowerCase().includes(q);
	});
}
function pickQuiz(chapterId, n, seed = Date.now()) {
	const pool = chapterId === "all" ? [...questions] : questions.filter((x) => x.chapterId === chapterId);
	const rand = mulberry32(seed);
	for (let i = pool.length - 1; i > 0; i--) {
		const j = Math.floor(rand() * (i + 1));
		[pool[i], pool[j]] = [pool[j], pool[i]];
	}
	return pool.slice(0, Math.min(n, pool.length));
}
function mulberry32(a) {
	return function next() {
		a += 1831565813;
		let t = a;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
//#endregion
export { pickQuiz as a, questionsForChapter as c, chapters as i, searchQuestions as l, chapterById as n, questionById as o, chapterCounts as r, questions as s, TOTAL_QUESTIONS as t };

import { create } from "zustand";
import { persist } from "zustand/middleware";

type QuizRecord = {
  at: number;
  chapterId: string;
  score: number;
  total: number;
};

type ProgressState = {
  seen: Record<string, true>;
  results: Record<string, boolean>;
  bookmarks: string[];
  quizzes: QuizRecord[];
  markSeen: (id: string) => void;
  markResult: (id: string, correct: boolean) => void;
  toggleBookmark: (id: string) => void;
  addQuiz: (record: QuizRecord) => void;
  reset: () => void;
};

export const useProgress = create<ProgressState>()(
  persist(
    (set) => ({
      seen: {},
      results: {},
      bookmarks: [],
      quizzes: [],
      markSeen: (id) => set((s) => ({ seen: { ...s.seen, [id]: true } })),
      markResult: (id, correct) =>
        set((s) => ({
          seen: { ...s.seen, [id]: true },
          results: { ...s.results, [id]: correct },
        })),
      toggleBookmark: (id) =>
        set((s) => ({
          bookmarks: s.bookmarks.includes(id)
            ? s.bookmarks.filter((x) => x !== id)
            : [...s.bookmarks, id],
        })),
      addQuiz: (record) => set((s) => ({ quizzes: [record, ...s.quizzes].slice(0, 20) })),
      reset: () => set({ seen: {}, results: {}, bookmarks: [], quizzes: [] }),
    }),
    { name: "kbm-padam-progress" },
  ),
);

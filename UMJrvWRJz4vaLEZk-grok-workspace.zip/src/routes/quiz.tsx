import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { QuestionBlock } from "@/components/question-block";
import { Button } from "@/components/ui/button";
import { chapters } from "@/data/chapters";
import { pickQuiz } from "@/data/questions";
import { useProgress } from "@/lib/progress";

export const Route = createFileRoute("/quiz")({ component: QuizPage });

function QuizPage() {
  const [chapterId, setChapterId] = useState("all");
  const [n, setN] = useState(10);
  const [seed, setSeed] = useState<number | null>(null);
  const [idx, setIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState(false);
  const [done, setDone] = useState(false);
  const addQuiz = useProgress((s) => s.addQuiz);

  const paper = useMemo(
    () => (seed == null ? [] : pickQuiz(chapterId, n, seed)),
    [chapterId, n, seed],
  );
  const current = paper[idx];

  function start() {
    setSeed(Date.now());
    setIdx(0);
    setScore(0);
    setAnswered(false);
    setDone(false);
  }

  function onAnswered(ok: boolean) {
    if (answered) return;
    setAnswered(true);
    if (ok) setScore((s) => s + 1);
  }

  function next() {
    if (idx + 1 >= paper.length) {
      setDone(true);
      addQuiz({ at: Date.now(), chapterId, score: score, total: paper.length });
      return;
    }
    setIdx((i) => i + 1);
    setAnswered(false);
  }

  if (seed != null && current && !done) {
    return (
      <div className="space-y-5">
        <header className="flex items-end justify-between gap-3">
          <div>
            <h1 className="font-display text-2xl font-semibold text-forest">ക്വിസ്</h1>
            <p className="text-sm text-ink-muted tabular-nums">
              {idx + 1} / {paper.length} · സ്കോർ {score}
            </p>
          </div>
          <Button variant="ghost" onClick={() => setSeed(null)}>
            നിർത്തുക
          </Button>
        </header>
        <QuestionBlock
          key={current.id}
          q={current}
          index={idx + 1}
          mode="quiz"
          onAnswered={onAnswered}
        />
        {answered ? (
          <Button onClick={next} className="w-full sm:w-auto">
            {idx + 1 >= paper.length ? "ഫലം കാണുക" : "അടുത്ത ചോദ്യം"}
          </Button>
        ) : null}
      </div>
    );
  }

  if (done) {
    const pct = paper.length ? Math.round((score / paper.length) * 100) : 0;
    return (
      <div className="rounded-xl border border-border bg-card p-6 text-center shadow-[var(--shadow-rule)]">
        <p className="font-display text-xs tracking-[0.2em] text-sage uppercase">Result</p>
        <h1 className="mt-2 font-display text-3xl font-semibold text-forest tabular-nums">
          {score} / {paper.length}
        </h1>
        <p className="mt-2 text-sm text-ink-muted">{pct}% ശരി. തെറ്റിയവ വീണ്ടും പഠനത്തിൽ നോക്കുക.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <Button onClick={start}>വീണ്ടും</Button>
          <Button variant="outline" onClick={() => setSeed(null)}>
            ക്രമീകരണം
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <header>
        <h1 className="font-display text-2xl font-semibold text-forest">ക്വിസ്</h1>
        <p className="mt-1 text-sm text-ink-muted">
          അധ്യായം തിരഞ്ഞെടുക്കുക. ഉത്തരം ശേഷം വിശദീകരണം കാണാം; അവസാനം സ്കോർ.
        </p>
      </header>
      <div className="rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-rule)]">
        <label className="text-sm font-medium text-ink" htmlFor="chapter">
          അധ്യായം
        </label>
        <select
          id="chapter"
          value={chapterId}
          onChange={(e) => setChapterId(e.target.value)}
          className="mt-2 flex h-11 w-full rounded-md border border-input bg-card px-3 text-sm"
        >
          <option value="all">എല്ലാ അധ്യായങ്ങളും (mixed)</option>
          {chapters.map((c) => (
            <option key={c.id} value={c.id}>
              {c.roman}. {c.titleEn}
            </option>
          ))}
        </select>
        <p className="mt-4 text-sm font-medium text-ink">ചോദ്യങ്ങളുടെ എണ്ണം</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {[10, 20, 50].map((k) => (
            <Button key={k} variant={n === k ? "default" : "outline"} onClick={() => setN(k)}>
              {k}
            </Button>
          ))}
        </div>
        <Button className="mt-6 w-full sm:w-auto" onClick={start}>
          തുടങ്ങുക
        </Button>
      </div>
    </div>
  );
}

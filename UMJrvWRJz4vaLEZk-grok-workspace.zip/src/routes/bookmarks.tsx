import { createFileRoute } from "@tanstack/react-router";
import { QuestionBlock } from "@/components/question-block";
import { questionById } from "@/data/questions";
import type { Question } from "@/data/types";
import { useProgress } from "@/lib/progress";

export const Route = createFileRoute("/bookmarks")({ component: BookmarksPage });

function BookmarksPage() {
  const ids = useProgress((s) => s.bookmarks);
  const list = ids.map(questionById).filter((q): q is Question => q != null);

  return (
    <div className="space-y-5">
      <header>
        <h1 className="font-display text-2xl font-semibold text-forest">സൂക്ഷിപ്പ്</h1>
        <p className="mt-1 text-sm text-ink-muted">
          പിന്നീട് ആവർത്തിക്കാൻ ബുക്ക്‌മാർക്ക് ചെയ്ത ചോദ്യങ്ങൾ. ബ്രൗസറിൽ സൂക്ഷിക്കുന്നു.
        </p>
      </header>
      {list.length === 0 ? (
        <p className="rounded-xl border border-border bg-card p-6 text-sm text-ink-muted">
          ഇതുവരെ ബുക്ക്‌മാർക്ക് ഇല്ല. പഠനത്തിൽ ബുക്ക് ഐക്കൺ അമർത്തുക.
        </p>
      ) : (
        <div className="grid gap-4">
          {list.map((q, i) => (
            <QuestionBlock key={q.id} q={q} index={i + 1} mode="study" />
          ))}
        </div>
      )}
    </div>
  );
}
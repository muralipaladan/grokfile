import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, BookOpen, FileDown, PenLine, Search } from "lucide-react";
import { Emblem } from "@/components/emblem";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { chapters } from "@/data/chapters";
import { chapterCounts, TOTAL_QUESTIONS } from "@/data/questions";
import { useProgress } from "@/lib/progress";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const seen = useProgress((s) => s.seen);
  const results = useProgress((s) => s.results);
  const seenN = Object.keys(seen).length;
  const right = Object.values(results).filter(Boolean).length;
  const counts = chapterCounts();

  return (
    <div className="space-y-8">
      <section className="rounded-xl border border-border bg-card px-5 py-8 shadow-[var(--shadow-rule)] sm:px-8">
        <div className="flex flex-col gap-6 sm:flex-row sm:items-center">
          <Emblem className="size-16 text-forest" />
          <div className="min-w-0">
            <p className="font-display text-[11px] font-semibold tracking-[0.22em] text-sage uppercase">
              Finance Department · Government of Kerala
            </p>
            <h1 className="mt-1 font-display text-3xl font-semibold text-forest sm:text-4xl">
              കെബിഎം പഠനം
            </h1>
            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-muted sm:text-base">
              Kerala Budget Manual (Third Edition) — {TOTAL_QUESTIONS} Department Test MCQs.
              ചോദ്യങ്ങൾ ഇംഗ്ലീഷിൽ, വിശദീകരണം ലളിതമായ മലയാളത്തിൽ. ഉത്തരം തെറ്റിയാൽ എന്തുകൊണ്ട്
              എന്ന് വ്യക്തമായി മനസ്സിലാകും. മുഴുവൻ Q-Bank PDF ആയി ഡൗൺലോഡ് ചെയ്യാം.
            </p>
          </div>
        </div>
        <div className="mt-6 grid gap-2 sm:grid-cols-3">
          <Button asChild>
            <Link to="/study">
              <BookOpen className="size-4" />
              അധ്യായം തിരഞ്ഞ് പഠിക്കുക
              <ArrowRight className="size-4" />
            </Link>
          </Button>
          <Button asChild variant="secondary">
            <Link to="/quiz">
              <PenLine className="size-4" />
              ക്വിസ് എഴുതുക
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link to="/print">
              <FileDown className="size-4" />
              PDF ഡൗൺലോഡ്
            </Link>
          </Button>
        </div>
      </section>

      <section className="rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-rule)]">
        <div className="flex items-end justify-between gap-3">
          <div>
            <h2 className="font-display text-lg font-semibold text-forest">നിങ്ങളുടെ പുരോഗതി</h2>
            <p className="text-sm text-ink-muted">
              കണ്ടത് {seenN} / {TOTAL_QUESTIONS} · ശരി {right}
            </p>
          </div>
          <Link to="/search" className="inline-flex h-11 items-center gap-1 text-sm text-forest">
            <Search className="size-4" />
            തിരയുക
          </Link>
        </div>
        <Progress className="mt-3" value={(seenN / TOTAL_QUESTIONS) * 100} />
      </section>

      <section>
        <h2 className="font-display text-lg font-semibold text-forest">അധ്യായങ്ങൾ</h2>
        <ul className="mt-3 grid gap-3 sm:grid-cols-2">
          {chapters.map((c) => (
            <li key={c.id}>
              <Link
                to="/study/$chapterId"
                params={{ chapterId: c.id }}
                className="block rounded-xl border border-border bg-card p-4 shadow-[var(--shadow-rule)] transition-shadow duration-150 hover:shadow-[var(--shadow-lift)]"
              >
                <p className="font-display text-xs tracking-widest text-sage uppercase">
                  Chapter {c.roman} · Paras {c.paras}
                </p>
                <h3 className="mt-1 font-display text-base font-semibold text-ink">{c.titleEn}</h3>
                <p className="text-sm text-forest">{c.titleMl}</p>
                <p className="mt-2 text-sm leading-relaxed text-ink-muted">{c.blurbMl}</p>
                <p className="mt-3 text-xs font-medium text-sage tabular-nums">
                  {counts[c.id] ?? 0} ചോദ്യങ്ങൾ
                </p>
              </Link>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { QuestionBlock } from "@/components/question-block";
import { Input } from "@/components/ui/input";
import { searchQuestions } from "@/data/questions";

export const Route = createFileRoute("/search")({ component: SearchPage });

function SearchPage() {
  const [q, setQ] = useState("");
  const hits = useMemo(() => searchQuestions(q).slice(0, 40), [q]);

  return (
    <div className="space-y-5">
      <header>
        <h1 className="font-display text-2xl font-semibold text-forest">തിരയുക</h1>
        <p className="mt-1 text-sm text-ink-muted">
          Article, paragraph, bougette, PAC, reappropriation തുടങ്ങിയ കീവേഡുകൾ.
        </p>
      </header>
      <Input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="ചോദ്യമോ വിഷയമോ ടൈപ്പ് ചെയ്യുക"
        aria-label="Search questions"
      />
      {q.trim() ? (
        <p className="text-sm text-ink-muted tabular-nums">{hits.length} ഫലം (പരമാവധി 40)</p>
      ) : null}
      <div className="grid gap-4">
        {hits.map((item, i) => (
          <QuestionBlock key={item.id} q={item} index={i + 1} mode="study" />
        ))}
      </div>
    </div>
  );
}

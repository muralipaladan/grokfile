import { createFileRoute, Link } from "@tanstack/react-router";
import { chapters } from "@/data/chapters";
import { questionsForChapter } from "@/data/questions";
import { useProgress } from "@/lib/progress";

export const Route = createFileRoute("/study/")({ component: StudyIndex });

function StudyIndex() {
  const results = useProgress((s) => s.results);

  return (
    <div className="space-y-5">
      <header>
        <h1 className="font-display text-2xl font-semibold text-forest">പഠനം</h1>
        <p className="mt-1 text-sm text-ink-muted">
          ഒരു അധ്യായം തുറന്ന് ചോദ്യം വായിക്കുക, ഓപ്ഷൻ തിരഞ്ഞെടുക്കുക, മലയാളം വിശദീകരണം
          നോക്കുക.
        </p>
      </header>
      <ol className="grid gap-3">
        {chapters.map((c, i) => {
          const list = questionsForChapter(c.id);
          const done = list.filter((q) => results[q.id]).length;
          return (
            <li key={c.id}>
              <Link
                to="/study/$chapterId"
                params={{ chapterId: c.id }}
                className="flex items-start gap-4 rounded-xl border border-border bg-card p-4 shadow-[var(--shadow-rule)] hover:shadow-[var(--shadow-lift)]"
              >
                <span className="font-display text-sm font-semibold text-sage tabular-nums">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block font-display font-semibold text-ink">{c.titleEn}</span>
                  <span className="block text-sm text-forest">{c.titleMl}</span>
                  <span className="mt-1 block text-sm text-ink-muted">{c.blurbMl}</span>
                </span>
                <span className="shrink-0 text-right text-xs text-ink-muted tabular-nums">
                  {done}/{list.length}
                  <span className="block">ശരി/ആകെ</span>
                </span>
              </Link>
            </li>
          );
        })}
      </ol>
    </div>
  );
}

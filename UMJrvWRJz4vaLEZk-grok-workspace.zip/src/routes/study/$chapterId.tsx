import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { QuestionBlock } from "@/components/question-block";
import { chapterById } from "@/data/chapters";
import { questionsForChapter } from "@/data/questions";
import type { ChapterId } from "@/data/types";

export const Route = createFileRoute("/study/$chapterId")({
  component: ChapterStudy,
});

function ChapterStudy() {
  const { chapterId } = Route.useParams();
  const chapter = chapterById(chapterId);
  if (!chapter) throw notFound();
  const list = questionsForChapter(chapter.id as ChapterId);

  return (
    <div className="space-y-5">
      <Link to="/study" className="inline-flex h-11 items-center gap-2 text-sm text-forest">
        <ArrowLeft className="size-4" />
        എല്ലാ അധ്യായങ്ങളും
      </Link>
      <header>
        <p className="font-display text-xs tracking-[0.18em] text-sage uppercase">
          Chapter {chapter.roman} · Paras {chapter.paras} · {list.length} questions
        </p>
        <h1 className="mt-1 font-display text-2xl font-semibold text-forest">{chapter.titleEn}</h1>
        <p className="text-sm text-ink-muted">
          {chapter.titleMl}. {chapter.blurbMl}
        </p>
      </header>
      <div className="grid gap-4">
        {list.map((q, i) => (
          <QuestionBlock key={q.id} q={q} index={i + 1} mode="study" />
        ))}
      </div>
    </div>
  );
}

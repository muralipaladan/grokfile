import { createFileRoute } from "@tanstack/react-router";
import { Download, Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { chapters } from "@/data/chapters";
import { questions, questionsForChapter, TOTAL_QUESTIONS } from "@/data/questions";

export const Route = createFileRoute("/print")({ component: PrintPage });

const LETTERS = ["A", "B", "C", "D"] as const;

function PrintPage() {
  return (
    <div className="print-area space-y-8">
      <header className="no-print flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold text-forest">PDF / പ്രിന്റ്</h1>
          <p className="mt-1 max-w-xl text-sm text-ink-muted">
            {TOTAL_QUESTIONS} ചോദ്യങ്ങൾ, ഉത്തരം, മലയാളം വിശദീകരണം. ഡൗൺലോഡ് ബട്ടൺ ഒരു
            തയ്യാറായ PDF തുറക്കും; അല്ലെങ്കിൽ ഈ പേജ് പ്രിന്റ് ചെയ്യാം.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button asChild>
            <a href="/kbm-department-test-qbank.pdf" download>
              <Download className="size-4" />
              PDF ഡൗൺലോഡ്
            </a>
          </Button>
          <Button variant="outline" onClick={() => window.print()}>
            <Printer className="size-4" />
            പ്രിന്റ്
          </Button>
        </div>
      </header>

      <div className="print-cover rounded-xl border border-border bg-card px-5 py-8 text-center">
        <p className="font-display text-[11px] tracking-[0.22em] text-sage uppercase">
          Government of Kerala · Finance Department
        </p>
        <h2 className="mt-2 font-display text-3xl font-semibold text-forest">KBM Padam</h2>
        <p className="text-lg text-ink">കേരള ബജറ്റ് മാനുവൽ · Department Test Q-Bank</p>
        <p className="mt-3 text-sm text-ink-muted">
          Third Edition (First Reprint) · corrections up to 30 June 1982 · {TOTAL_QUESTIONS}{" "}
          MCQs · English questions · Malayalam explanations
        </p>
      </div>

      {chapters.map((ch) => {
        const list = questionsForChapter(ch.id);
        return (
          <section key={ch.id} className="break-inside-avoid">
            <h2 className="font-display text-xl font-semibold text-forest">
              Chapter {ch.roman}. {ch.titleEn}
            </h2>
            <p className="mb-4 text-sm text-ink-muted">
              {ch.titleMl} · Paras {ch.paras}
            </p>
            <ol className="grid gap-6">
              {list.map((q, i) => (
                <li key={q.id} className="break-inside-avoid border-b border-border pb-4">
                  <p className="font-display text-xs text-sage">
                    {i + 1}. Para {q.para} · {q.difficulty}
                  </p>
                  <p className="mt-1 font-display font-semibold text-ink">{q.question}</p>
                  <ul className="mt-2 grid gap-1 text-sm">
                    {q.options.map((opt, oi) => (
                      <li key={opt}>
                        <span className="font-medium">{LETTERS[oi]}.</span> {opt}
                      </li>
                    ))}
                  </ul>
                  <p className="mt-2 text-sm font-medium text-forest">
                    ഉത്തരം: {LETTERS[q.answer]}. {q.options[q.answer]}
                  </p>
                  <p className="mt-1 text-sm leading-relaxed text-ink">{q.explanationMl}</p>
                  <p className="mt-1 text-sm text-ink-muted">{q.explanationEn}</p>
                </li>
              ))}
            </ol>
          </section>
        );
      })}
      <p className="hidden text-center text-xs text-ink-faint">
        {questions.length} questions · For personal departmental-test study. Source: Kerala Budget
        Manual.
      </p>
    </div>
  );
}
